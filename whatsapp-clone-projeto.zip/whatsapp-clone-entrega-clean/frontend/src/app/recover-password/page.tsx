'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

export default function PasswordRecovery() {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [step, setStep] = useState<'email' | 'code' | 'newPassword'>('email');
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const router = useRouter();

  // Solicitar código de recuperação
  const requestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);
    
    try {
      await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/auth/request-password-reset`, { email });
      
      setMessage({
        text: 'Código de recuperação enviado para seu email!',
        type: 'success'
      });
      
      setStep('code');
    } catch (error) {
      console.error('Erro ao solicitar código:', error);
      setMessage({
        text: error.response?.data?.message || 'Erro ao solicitar código. Verifique seu email.',
        type: 'error'
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Verificar código e avançar para definição de nova senha
  const verifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);
    
    try {
      await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/auth/verify-reset-code`, { 
        email, 
        code 
      });
      
      setMessage({
        text: 'Código verificado com sucesso!',
        type: 'success'
      });
      
      setStep('newPassword');
    } catch (error) {
      console.error('Erro ao verificar código:', error);
      setMessage({
        text: error.response?.data?.message || 'Código inválido ou expirado.',
        type: 'error'
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Redefinir senha
  const resetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);
    
    // Validar senhas
    if (newPassword !== confirmPassword) {
      setMessage({
        text: 'As senhas não coincidem.',
        type: 'error'
      });
      setIsLoading(false);
      return;
    }
    
    if (newPassword.length < 8) {
      setMessage({
        text: 'A senha deve ter pelo menos 8 caracteres.',
        type: 'error'
      });
      setIsLoading(false);
      return;
    }
    
    try {
      await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/auth/reset-password`, {
        email,
        code,
        newPassword
      });
      
      setMessage({
        text: 'Senha redefinida com sucesso!',
        type: 'success'
      });
      
      // Redirecionar para login após 2 segundos
      setTimeout(() => {
        router.push('/login');
      }, 2000);
    } catch (error) {
      console.error('Erro ao redefinir senha:', error);
      setMessage({
        text: error.response?.data?.message || 'Erro ao redefinir senha. Tente novamente.',
        type: 'error'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md max-w-md mx-auto">
      <h2 className="text-2xl font-semibold mb-6 text-gray-800">Recuperação de Senha</h2>
      
      {message && (
        <div className={`p-3 mb-4 rounded ${message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
          {message.text}
        </div>
      )}
      
      {step === 'email' && (
        <form onSubmit={requestCode}>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
              Email
            </label>
            <input
              id="email"
              type="email"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="Digite seu email cadastrado"
            />
          </div>
          
          <button
            type="submit"
            className={`w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
            disabled={isLoading}
          >
            {isLoading ? 'Enviando...' : 'Enviar Código de Recuperação'}
          </button>
          
          <div className="mt-4 text-center">
            <button
              type="button"
              className="text-green-600 hover:text-green-700"
              onClick={() => router.push('/login')}
            >
              Voltar para o login
            </button>
          </div>
        </form>
      )}
      
      {step === 'code' && (
        <form onSubmit={verifyCode}>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="code">
              Código de Verificação
            </label>
            <input
              id="code"
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              required
              placeholder="Digite o código recebido por email"
            />
          </div>
          
          <button
            type="submit"
            className={`w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
            disabled={isLoading}
          >
            {isLoading ? 'Verificando...' : 'Verificar Código'}
          </button>
          
          <div className="mt-4 text-center">
            <button
              type="button"
              className="text-green-600 hover:text-green-700"
              onClick={() => setStep('email')}
            >
              Voltar
            </button>
          </div>
        </form>
      )}
      
      {step === 'newPassword' && (
        <form onSubmit={resetPassword}>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="newPassword">
              Nova Senha
            </label>
            <input
              id="newPassword"
              type="password"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
              minLength={8}
              placeholder="Mínimo de 8 caracteres"
            />
          </div>
          
          <div className="mb-6">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="confirmPassword">
              Confirmar Nova Senha
            </label>
            <input
              id="confirmPassword"
              type="password"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              placeholder="Digite a senha novamente"
            />
          </div>
          
          <button
            type="submit"
            className={`w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
            disabled={isLoading}
          >
            {isLoading ? 'Redefinindo...' : 'Redefinir Senha'}
          </button>
          
          <div className="mt-4 text-center">
            <button
              type="button"
              className="text-green-600 hover:text-green-700"
              onClick={() => setStep('code')}
            >
              Voltar
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
