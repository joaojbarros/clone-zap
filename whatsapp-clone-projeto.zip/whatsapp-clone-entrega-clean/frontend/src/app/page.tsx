'use client';

import { useState, useEffect } from 'react';
import Sidebar from "@/components/Sidebar";
import ChatArea from "@/components/ChatArea";
import Header from "@/components/Header";
import { useChat } from '@/contexts/ChatContext';

export default function Home() {
  const [showMobileSidebar, setShowMobileSidebar] = useState(true);
  const { activeContactId } = useChat();

  // Alternar para a visualização de chat quando um contato é selecionado em dispositivos móveis
  useEffect(() => {
    if (activeContactId && window.innerWidth < 768) {
      setShowMobileSidebar(false);
    }
  }, [activeContactId]);

  return (
    <main className="flex flex-col md:flex-row w-full h-full">
      {/* Mobile View */}
      <div className={`md:hidden w-full h-full ${showMobileSidebar ? 'block' : 'hidden'}`}>
        <Header />
        <Sidebar />
      </div>
      
      <div className={`md:hidden w-full h-full ${!showMobileSidebar ? 'block' : 'hidden'}`}>
        <Header />
        <ChatArea onBackClick={() => setShowMobileSidebar(true)} />
      </div>
      
      {/* Desktop View */}
      <div className="hidden md:block">
        <Sidebar />
      </div>
      <div className="hidden md:flex flex-1">
        <ChatArea />
      </div>
    </main>
  );
}
