import { createContext, useContext, useState, useEffect, ReactNode, useCallback, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import axios from 'axios';
import { useAuth } from './AuthContext';

// Interfaces para tipagem
export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  type: 'text' | 'image' | 'audio' | 'emoji';
  text?: string;
  mediaUrl?: string;
  audioDuration?: number;
  timestamp: Date;
  status: {
    deliveredTo: string[];
    readBy: string[];
  };
}

export interface Contact {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  status: 'online' | 'offline';
  lastSeen: Date;
}

export interface Conversation {
  id: string;
  participants: string[];
  type: 'private' | 'group';
  lastMessage?: {
    messageId: string;
    text: string;
    senderId: string;
    timestamp: Date;
  };
  createdAt: Date;
  updatedAt: Date;
  groupName?: string;
  groupAvatarUrl?: string;
}

interface ChatContextType {
  contacts: Contact[];
  conversations: Conversation[];
  activeContactId: string | null;
  activeConversationId: string | null;
  messages: Message[];
  isLoading: boolean;
  error: string | null;
  typingUsers: Record<string, boolean>;
  setActiveContact: (contactId: string) => void;
  setActiveConversation: (conversationId: string) => void;
  sendMessage: (text: string, type?: 'text' | 'emoji') => Promise<boolean>;
  sendMediaMessage: (file: File, type: 'image' | 'audio', duration?: number) => Promise<boolean>;
  markMessageAsRead: (messageId: string) => void;
  searchContacts: (query: string) => Promise<Contact[]>;
  createConversation: (participantIds: string[], type: 'private' | 'group', groupName?: string) => Promise<string | null>;
  startTyping: () => void;
  stopTyping: () => void;
  getLastMessage: (contactId: string) => { text: string; timestamp: Date } | null;
  getUnreadCount: (contactId: string) => number;
  updatePrivacySettings: (settings: { hideOnlineStatus: boolean; hideReadReceipts: boolean }) => Promise<boolean>;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider = ({ children }: { children: ReactNode }) => {
  const { user, token, isAuthenticated } = useAuth();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeContactId, setActiveContactId] = useState<string | null>(null);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [typingUsers, setTypingUsers] = useState<Record<string, boolean>>({});
  
  const socketRef = useRef<Socket | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Inicializar Socket.IO quando o usuário estiver autenticado
  useEffect(() => {
    if (isAuthenticated && token) {
      // Conectar ao servidor Socket.IO
      socketRef.current = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:8000', {
        auth: {
          token
        }
      });

      // Configurar eventos do Socket.IO
      const socket = socketRef.current;

      socket.on('connect', () => {
        console.log('Conectado ao servidor Socket.IO');
      });

      socket.on('disconnect', () => {
        console.log('Desconectado do servidor Socket.IO');
      });

      socket.on('error', (error) => {
        console.error('Erro no Socket.IO:', error);
        setError(`Erro de conexão: ${error.message}`);
      });

      // Evento para receber novas mensagens
      socket.on('newMessage', (message: Message) => {
        // Adicionar a nova mensagem à lista de mensagens
        setMessages(prevMessages => {
          // Verificar se a mensagem já existe
          const messageExists = prevMessages.some(msg => msg.id === message.id);
          if (messageExists) {
            return prevMessages;
          }
          return [...prevMessages, {
            ...message,
            timestamp: new Date(message.timestamp)
          }];
        });

        // Atualizar a última mensagem na conversa
        setConversations(prevConversations => {
          return prevConversations.map(conv => {
            if (conv.id === message.conversationId) {
              return {
                ...conv,
                lastMessage: {
                  messageId: message.id,
                  text: message.text || `[${message.type.toUpperCase()}]`,
                  senderId: message.senderId,
                  timestamp: new Date(message.timestamp)
                }
              };
            }
            return conv;
          });
        });

        // Se a mensagem não é do usuário atual e está na conversa ativa, marcar como lida
        if (message.senderId !== user?.id && message.conversationId === activeConversationId) {
          socket.emit('markMessageAsRead', {
            messageId: message.id,
            conversationId: message.conversationId
          });
        }
      });

      // Evento para status de digitação
      socket.on('userTyping', ({ userId, conversationId }) => {
        if (conversationId === activeConversationId) {
          setTypingUsers(prev => ({ ...prev, [userId]: true }));
        }
      });

      socket.on('userStopTyping', ({ userId }) => {
        setTypingUsers(prev => ({ ...prev, [userId]: false }));
      });

      // Eventos para status de mensagem
      socket.on('messageDelivered', ({ messageId, userId }) => {
        setMessages(prevMessages => {
          return prevMessages.map(msg => {
            if (msg.id === messageId) {
              return {
                ...msg,
                status: {
                  ...msg.status,
                  deliveredTo: [...msg.status.deliveredTo, userId]
                }
              };
            }
            return msg;
          });
        });
      });

      socket.on('messageRead', ({ messageId, userId }) => {
        setMessages(prevMessages => {
          return prevMessages.map(msg => {
            if (msg.id === messageId) {
              return {
                ...msg,
                status: {
                  ...msg.status,
                  readBy: [...msg.status.readBy, userId]
                }
              };
            }
            return msg;
          });
        });
      });

      // Eventos para status de usuário
      socket.on('userOnline', ({ userId }) => {
        setContacts(prevContacts => {
          return prevContacts.map(contact => {
            if (contact.id === userId) {
              return {
                ...contact,
                status: 'online'
              };
            }
            return contact;
          });
        });
      });

      socket.on('userOffline', ({ userId, lastSeen }) => {
        setContacts(prevContacts => {
          return prevContacts.map(contact => {
            if (contact.id === userId) {
              return {
                ...contact,
                status: 'offline',
                lastSeen: new Date(lastSeen)
              };
            }
            return contact;
          });
        });
      });

      // Limpar conexão ao desmontar
      return () => {
        if (socket) {
          socket.disconnect();
        }
      };
    }
  }, [isAuthenticated, token, activeConversationId, user?.id]);

  // Carregar contatos e conversas quando o usuário estiver autenticado
  useEffect(() => {
    if (isAuthenticated && token) {
      loadContacts();
      loadConversations();
    }
  }, [isAuthenticated, token]);

  // Carregar mensagens quando a conversa ativa mudar
  useEffect(() => {
    if (activeConversationId) {
      loadMessages(activeConversationId);
      
      // Entrar na sala da conversa via Socket.IO
      if (socketRef.current) {
        socketRef.current.emit('joinConversation', activeConversationId);
      }
      
      // Limpar ao mudar de conversa
      return () => {
        if (socketRef.current) {
          socketRef.current.emit('leaveConversation', activeConversationId);
        }
      };
    }
  }, [activeConversationId]);

  // Função para carregar contatos
  const loadContacts = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/users/contacts`);
      setContacts(response.data.contacts.map((contact: any) => ({
        ...contact,
        lastSeen: new Date(contact.lastSeen)
      })));
      setIsLoading(false);
    } catch (error) {
      console.error('Erro ao carregar contatos:', error);
      setError('Erro ao carregar contatos. Tente novamente.');
      setIsLoading(false);
    }
  };

  // Função para carregar conversas
  const loadConversations = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/conversations`);
      setConversations(response.data.conversations.map((conv: any) => ({
        ...conv,
        createdAt: new Date(conv.createdAt),
        updatedAt: new Date(conv.updatedAt),
        lastMessage: conv.lastMessage ? {
          ...conv.lastMessage,
          timestamp: new Date(conv.lastMessage.timestamp)
        } : undefined
      })));
      setIsLoading(false);
    } catch (error) {
      console.error('Erro ao carregar conversas:', error);
      setError('Erro ao carregar conversas. Tente novamente.');
      setIsLoading(false);
    }
  };

  // Função para carregar mensagens de uma conversa
  const loadMessages = async (conversationId: string) => {
    try {
      setIsLoading(true);
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/conversations/${conversationId}/messages`);
      setMessages(response.data.messages.map((msg: any) => ({
        ...msg,
        timestamp: new Date(msg.timestamp)
      })));
      setIsLoading(false);
    } catch (error) {
      console.error('Erro ao carregar mensagens:', error);
      setError('Erro ao carregar mensagens. Tente novamente.');
      setIsLoading(false);
    }
  };

  // Função para definir o contato ativo
  const setActiveContact = useCallback((contactId: string) => {
    setActiveContactId(contactId);
    
    // Encontrar ou criar conversa com este contato
    const existingConversation = conversations.find(conv => 
      conv.type === 'private' && 
      conv.participants.includes(contactId) && 
      conv.participants.length === 2
    );
    
    if (existingConversation) {
      setActiveConversationId(existingConversation.id);
    } else {
      // Criar nova conversa com este contato
      createConversation([contactId], 'private').then(conversationId => {
        if (conversationId) {
          setActiveConversationId(conversationId);
        }
      });
    }
  }, [conversations]);

  // Função para definir a conversa ativa
  const setActiveConversation = useCallback((conversationId: string) => {
    setActiveConversationId(conversationId);
    
    // Encontrar o contato principal desta conversa (para conversas privadas)
    const conversation = conversations.find(conv => conv.id === conversationId);
    if (conversation && conversation.type === 'private') {
      const otherParticipantId = conversation.participants.find(id => id !== user?.id);
      if (otherParticipantId) {
        setActiveContactId(otherParticipantId);
      }
    } else {
      // Para grupos, não há um contato ativo específico
      setActiveContactId(null);
    }
  }, [conversations, user?.id]);

  // Função para enviar mensagem de texto
  const sendMessage = async (text: string, type: 'text' | 'emoji' = 'text'): Promise<boolean> => {
    if (!activeConversationId || !text.trim()) {
      return false;
    }
    
    try {
      // Parar de digitar ao enviar mensagem
      stopTyping();
      
      // Enviar via Socket.IO para tempo real
      if (socketRef.current) {
        socketRef.current.emit('sendMessage', {
          conversationId: activeConversationId,
          text,
          type
        });
        return true;
      }
      
      // Fallback para API REST se o Socket.IO não estiver disponível
      const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/conversations/${activeConversationId}/messages`, {
        text,
        type
      });
      
      return !!response.data.data;
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      setError('Erro ao enviar mensagem. Tente novamente.');
      return false;
    }
  };

  // Função para enviar mensagem com mídia
  const sendMediaMessage = async (file: File, type: 'image' | 'audio', duration?: number): Promise<boolean> => {
    if (!activeConversationId || !file) {
      return false;
    }
    
    try {
      // Criar FormData para upload
      const formData = new FormData();
      formData.append(type, file);
      
      if (type === 'audio' && duration) {
        formData.append('duration', duration.toString());
      }
      
      // Upload da mídia
      const uploadResponse = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/media/upload/${type}`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      
      const { mediaUrl, audioDuration } = uploadResponse.data;
      
      // Enviar mensagem com a URL da mídia
      if (socketRef.current) {
        socketRef.current.emit('sendMessage', {
          conversationId: activeConversationId,
          type,
          mediaUrl,
          audioDuration
        });
        return true;
      }
      
      // Fallback para API REST
      const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/conversations/${activeConversationId}/messages`, {
        type,
        mediaUrl,
        audioDuration
      });
      
      return !!response.data.data;
    } catch (error) {
      console.error(`Erro ao enviar ${type}:`, error);
      setError(`Erro ao enviar ${type}. Tente novamente.`);
      return false;
    }
  };

  // Função para marcar mensagem como lida
  const markMessageAsRead = (messageId: string) => {
    if (!activeConversationId || !socketRef.current) {
      return;
    }
    
    socketRef.current.emit('markMessageAsRead', {
      messageId,
      conversationId: activeConversationId
    });
  };

  // Função para buscar contatos
  const searchContacts = async (query: string): Promise<Contact[]> => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/users/search?q=${query}`);
      return response.data.users.map((user: any) => ({
        ...user,
        lastSeen: new Date(user.lastSeen)
      }));
    } catch (error) {
      console.error('Erro ao buscar contatos:', error);
      setError('Erro ao buscar contatos. Tente novamente.');
      return [];
    }
  };

  // Função para criar conversa
  const createConversation = async (
    participantIds: string[], 
    type: 'private' | 'group', 
    groupName?: string
  ): Promise<string | null> => {
    try {
      const payload: any = {
        participantIds,
        type
      };
      
      if (type === 'group' && groupName) {
        payload.groupName = groupName;
      }
      
      const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/conversations`, payload);
      
      // Atualizar lista de conversas
      const newConversation = {
        ...response.data.conversation,
        createdAt: new Date(response.data.conversation.createdAt),
        updatedAt: new Date(response.data.conversation.updatedAt)
      };
      
      setConversations(prev => {
        // Verificar se a conversa já existe
        const exists = prev.some(conv => conv.id === newConversation.id);
        if (exists) {
          return prev;
        }
        return [...prev, newConversation];
      });
      
      return newConversation.id;
    } catch (error) {
      console.error('Erro ao criar conversa:', error);
      setError('Erro ao criar conversa. Tente novamente.');
      return null;
    }
  };

  // Funções para indicar digitação
  const startTyping = () => {
    if (!activeConversationId || !socketRef.current) {
      return;
    }
    
    socketRef.current.emit('typing', { conversationId: activeConversationId });
    
    // Limpar timeout anterior se existir
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    // Configurar novo timeout para parar de digitar após 3 segundos
    typingTimeoutRef.current = setTimeout(() => {
      stopTyping();
    }, 3000);
  };

  const stopTyping = () => {
    if (!activeConversationId || !socketRef.current) {
      return;
    }
    
    socketRef.current.emit('stopTyping', { conversationId: activeConversationId });
    
    // Limpar timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = null;
    }
  };

  // Função para obter a última mensagem de um contato
  const getLastMessage = (contactId: string) => {
    // Encontrar conversa com este contato
    const conversation = conversations.find(conv => 
      conv.type === 'private' && 
      conv.participants.includes(contactId) && 
      conv.participants.length === 2
    );
    
    if (conversation && conversation.lastMessage) {
      return {
        text: conversation.lastMessage.text,
        timestamp: conversation.lastMessage.timestamp
      };
    }
    
    return null;
  };

  // Função para obter contagem de mensagens não lidas
  const getUnreadCount = (contactId: string) => {
    // Encontrar conversa com este contato
    const conversation = conversations.find(conv => 
      conv.type === 'private' && 
      conv.participants.includes(contactId) && 
      conv.participants.length === 2
    );
    
    if (!conversation) {
      return 0;
    }
    
    // Contar mensagens não lidas nesta conversa
    return messages.filter(msg => 
      msg.conversationId === conversation.id && 
      msg.senderId === contactId && 
      !msg.status.readBy.includes(user?.id || '')
    ).length;
  };

  // Função para atualizar configurações de privacidade
  const updatePrivacySettings = async (settings: { hideOnlineStatus: boolean; hideReadReceipts: boolean }): Promise<boolean> => {
    try {
      const response = await axios.put(`${process.env.NEXT_PUBLIC_API_URL}/users/me`, {
        privacySettings: settings
      });
      
      return true;
    } catch (error) {
      console.error('Erro ao atualizar configurações de privacidade:', error);
      setError('Erro ao atualizar configurações de privacidade. Tente novamente.');
      return false;
    }
  };

  return (
    <ChatContext.Provider
      value={{
        contacts,
        conversations,
        activeContactId,
        activeConversationId,
        messages,
        isLoading,
        error,
        typingUsers,
        setActiveContact,
        setActiveConversation,
        sendMessage,
        sendMediaMessage,
        markMessageAsRead,
        searchContacts,
        createConversation,
        startTyping,
        stopTyping,
        getLastMessage,
        getUnreadCount,
        updatePrivacySettings
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat deve ser usado dentro de um ChatProvider');
  }
  return context;
};
