'use client';

import { useState, useEffect, useRef } from 'react';
import { useChat, Message } from '@/contexts/ChatContext';
import EmojiPicker from '@/components/EmojiPicker';

interface ChatAreaProps {
  onBackClick?: () => void;
}

export default function ChatArea({ onBackClick }: ChatAreaProps = {}) {
  const { 
    activeContactId, 
    contacts, 
    getContactMessages, 
    sendMessage 
  } = useChat();
  
  const [newMessage, setNewMessage] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingStartTime, setRecordingStartTime] = useState<number | null>(null);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const activeContact = contacts.find(contact => contact.id === activeContactId);
  const messages = activeContactId ? getContactMessages(activeContactId) : [];

  // Rolar para a última mensagem quando novas mensagens são adicionadas
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Atualizar duração da gravação
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording && recordingStartTime) {
      interval = setInterval(() => {
        const duration = Math.floor((Date.now() - recordingStartTime) / 1000);
        setRecordingDuration(duration);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording, recordingStartTime]);

  const handleSendMessage = () => {
    if (newMessage.trim() === '' || !activeContactId) return;
    
    sendMessage(newMessage, activeContactId);
    setNewMessage('');
  };

  const handleEmojiSelect = (emoji: string) => {
    setNewMessage(prev => prev + emoji);
    setShowEmojiPicker(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeContactId) return;

    // Simular upload de imagem
    const imageUrl = URL.createObjectURL(file);
    sendMessage(
      `[Imagem]`, 
      activeContactId, 
      'image', 
      imageUrl
    );

    // Limpar input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const startRecording = () => {
    setIsRecording(true);
    setRecordingStartTime(Date.now());
    // Aqui seria implementada a gravação real de áudio
  };

  const stopRecording = () => {
    if (!activeContactId || !recordingStartTime) return;
    
    setIsRecording(false);
    const duration = Math.floor((Date.now() - recordingStartTime) / 1000);
    
    // Simular envio de áudio
    sendMessage(
      `[Áudio: ${duration}s]`, 
      activeContactId, 
      'audio', 
      undefined, 
      duration
    );
    
    setRecordingStartTime(null);
    setRecordingDuration(0);
  };

  const renderMessage = (message: Message) => {
    switch (message.type) {
      case 'text':
        return <p className="text-sm">{message.text}</p>;
      case 'image':
        return (
          <div>
            <img 
              src={message.mediaUrl} 
              alt="Imagem enviada" 
              className="max-w-full rounded-md mb-1" 
              style={{ maxHeight: '200px' }}
            />
          </div>
        );
      case 'emoji':
        return <p className="text-3xl">{message.text}</p>;
      case 'audio':
        return (
          <div className="flex items-center space-x-2">
            <button className="p-1 bg-gray-200 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
              </svg>
            </button>
            <div className="h-1 bg-gray-300 flex-1 rounded-full">
              <div className="h-1 bg-green-500 rounded-full w-0"></div>
            </div>
            <span className="text-xs text-gray-500">{message.audioDuration}s</span>
          </div>
        );
      default:
        return <p className="text-sm">{message.text}</p>;
    }
  };

  if (!activeContactId || !activeContact) {
    return (
      <div className="flex-1 flex flex-col bg-[#e5ded8] items-center justify-center">
        <div className="text-gray-500 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
          <h3 className="text-xl font-semibold mb-2">WhatsApp Web</h3>
          <p className="max-w-md">Selecione um contato para iniciar uma conversa</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-[#e5ded8] w-full">
      {/* Chat Header */}
      <div className="bg-[#f0f2f5] p-3 flex justify-between items-center border-l border-gray-300">
        <div className="flex items-center">
          {onBackClick && (
            <button 
              className="md:hidden mr-2 text-gray-600"
              onClick={onBackClick}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
          )}
          <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
            <span className="text-gray-600">{activeContact.name.charAt(0)}</span>
          </div>
          <div className="ml-3">
            <h3 className="font-semibold">{activeContact.name}</h3>
            <p className="text-xs text-gray-500">
              {activeContact.status === 'online' 
                ? 'online' 
                : activeContact.lastSeen}
            </p>
          </div>
        </div>
        <div className="flex space-x-4 text-gray-600">
          <button className="p-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z" />
            </svg>
          </button>
          <button className="p-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
            </svg>
          </button>
          <button className="p-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[70%] rounded-lg p-2 ${
                message.sender === 'user' ? 'bg-[#d9fdd3]' : 'bg-white'
              }`}
            >
              {renderMessage(message)}
              <div className="flex justify-end items-center space-x-1 mt-1">
                <span className="text-xs text-gray-500">{message.timestamp}</span>
                {message.sender === 'user' && (
                  <span>
                    {message.status === 'sent' && (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    )}
                    {message.status === 'delivered' && (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M6.293 9.293a1 1 0 011.414 0L10 11.586l2.293-2.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    )}
                    {message.status === 'read' && (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M6.293 9.293a1 1 0 011.414 0L10 11.586l2.293-2.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    )}
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Emoji Picker */}
      {showEmojiPicker && (
        <div className="p-2 bg-white border-t border-gray-300">
          <EmojiPicker onSelect={handleEmojiSelect} />
        </div>
      )}

      {/* Message Input */}
      <div className="bg-[#f0f2f5] p-3 flex items-center">
        <button 
          className="p-2 text-gray-600"
          onClick={() => setShowEmojiPicker(!showEmojiPicker)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </button>
        
        <input 
          type="file" 
          accept="image/*" 
          className="hidden" 
          ref={fileInputRef}
          onChange={handleImageUpload}
        />
        
        <button 
          className="p-2 text-gray-600"
          onClick={() => fileInputRef.current?.click()}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
          </svg>
        </button>
        
        {isRecording ? (
          <div className="ml-2 flex-1 flex items-center bg-white rounded-lg py-2 px-4">
            <div className="animate-pulse mr-2">
              <span className="inline-block w-3 h-3 bg-red-500 rounded-full"></span>
            </div>
            <span className="text-gray-600">Gravando... {recordingDuration}s</span>
            <button 
              className="ml-auto text-red-500"
              onClick={stopRecording}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        ) : (
          <>
            <input
              type="text"
              placeholder="Digite uma mensagem"
              className="ml-2 py-2 px-4 rounded-lg flex-1 outline-none"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter') handleSendMessage();
              }}
            />
            
            {newMessage.trim() === '' ? (
              <button 
                className="p-2 ml-2 text-gray-600"
                onClick={startRecording}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </button>
            ) : (
              <button 
                className="p-2 ml-2 text-gray-600"
                onClick={handleSendMessage}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}
