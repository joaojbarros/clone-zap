'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import axios from 'axios';

export default function ProfileEditor() {
  const { user, token } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [avatar, setAvatar] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [hideOnlineStatus, setHideOnlineStatus] = useState(false);
  const [hideReadReceipts, setHideReadReceipts] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Carregar dados do usuário
  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setEmail(user.email || '');
      setAvatarPreview(user.avatarUrl || null);
      
      // Carregar configurações de privacidade
      if (user.privacySettings) {
        setHideOnlineStatus(user.privacySettings.hideOnlineStatus || false);
        setHideReadReceipts(user.privacySettings.hideReadReceipts || false);
      }
    }
  }, [user]);

  // Manipular seleção de avatar
  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Verificar tipo e tamanho
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      const maxSize = 5 * 1024 * 1024; // 5MB
      
      if (!validTypes.includes(file.type)) {
        setMessage({
          text: 'Formato de imagem inválido. Use JPEG, PNG, GIF ou WebP.',
          type: 'error'
        });
        return;
      }
      
      if (file.size > maxSize) {
        setMessage({
          text: 'Imagem muito grande. O tamanho máximo é 5MB.',
          type: 'error'
        });
        return;
      }
      
      setAvatar(file);
      
      // Criar preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setAvatarPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Enviar formulário
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);
    
    try {
      // Criar FormData para envio de arquivo
      const formData = new FormData();
      formData.append('name', name);
      formData.append('email', email);
      
      // Adicionar configurações de privacidade
      const privacySettings = {
        hideOnlineStatus,
        hideReadReceipts
      };
      formData.append('privacySettings', JSON.stringify(privacySettings));
      
      // Adicionar avatar se selecionado
      if (avatar) {
        formData.append('avatar', avatar);
      }
      
      // Enviar requisição
      const response = await axios.put(
        `${process.env.NEXT_PUBLIC_API_URL}/users/me`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      setMessage({
        text: 'Perfil atualizado com sucesso!',
        type: 'success'
      });
      
      // Atualizar dados do usuário no contexto (opcional, pode ser feito via recarregamento)
      // updateUser(response.data.user);
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      setMessage({
        text: error.response?.data?.message || 'Erro ao atualizar perfil. Tente novamente.',
        type: 'error'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md max-w-md mx-auto">
      <h2 className="text-2xl font-semibold mb-6 text-gray-800">Editar Perfil</h2>
      
      {message && (
        <div className={`p-3 mb-4 rounded ${message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
          {message.text}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        {/* Avatar */}
        <div className="mb-6 flex flex-col items-center">
          <div className="w-24 h-24 rounded-full overflow-hidden bg-gray-200 mb-2">
            {avatarPreview ? (
              <img 
                src={avatarPreview} 
                alt="Avatar" 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-gray-500">
                {name.charAt(0).toUpperCase()}
              </div>
            )}
          </div>
          
          <label className="cursor-pointer text-green-600 hover:text-green-700">
            Alterar foto
            <input 
              type="file" 
              accept="image/jpeg,image/png,image/gif,image/webp" 
              className="hidden" 
              onChange={handleAvatarChange}
            />
          </label>
        </div>
        
        {/* Nome */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="name">
            Nome
          </label>
          <input
            id="name"
            type="text"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            minLength={3}
          />
        </div>
        
        {/* Email */}
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
            Email
          </label>
          <input
            id="email"
            type="email"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        
        {/* Configurações de Privacidade */}
        <div className="mb-6 border-t pt-4">
          <h3 className="text-lg font-medium mb-3 text-gray-700">Configurações de Privacidade</h3>
          
          <div className="flex items-center mb-3">
            <input
              id="hideOnlineStatus"
              type="checkbox"
              className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
              checked={hideOnlineStatus}
              onChange={(e) => setHideOnlineStatus(e.target.checked)}
            />
            <label className="ml-2 block text-gray-700" htmlFor="hideOnlineStatus">
              Ocultar status online
            </label>
          </div>
          
          <div className="flex items-center">
            <input
              id="hideReadReceipts"
              type="checkbox"
              className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
              checked={hideReadReceipts}
              onChange={(e) => setHideReadReceipts(e.target.checked)}
            />
            <label className="ml-2 block text-gray-700" htmlFor="hideReadReceipts">
              Ocultar confirmações de leitura
            </label>
          </div>
        </div>
        
        {/* Botão de Salvar */}
        <button
          type="submit"
          className={`w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
          disabled={isLoading}
        >
          {isLoading ? 'Salvando...' : 'Salvar Alterações'}
        </button>
      </form>
    </div>
  );
}
