'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useChat } from '@/contexts/ChatContext';

export default function PrivacySettings() {
  const { user, token } = useAuth();
  const { updatePrivacySettings } = useChat();
  const [hideOnlineStatus, setHideOnlineStatus] = useState(false);
  const [hideReadReceipts, setHideReadReceipts] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Carregar configurações atuais
  useEffect(() => {
    if (user && user.privacySettings) {
      setHideOnlineStatus(user.privacySettings.hideOnlineStatus || false);
      setHideReadReceipts(user.privacySettings.hideReadReceipts || false);
    }
  }, [user]);

  // Salvar configurações
  const handleSave = async () => {
    setIsLoading(true);
    setMessage(null);
    
    try {
      const privacySettings = {
        hideOnlineStatus,
        hideReadReceipts
      };
      
      // Atualizar configurações via ChatContext
      const success = await updatePrivacySettings(privacySettings);
      
      if (success) {
        setMessage({
          text: 'Configurações de privacidade atualizadas com sucesso!',
          type: 'success'
        });
      } else {
        throw new Error('Falha ao atualizar configurações');
      }
    } catch (error) {
      console.error('Erro ao atualizar configurações de privacidade:', error);
      setMessage({
        text: 'Erro ao atualizar configurações. Tente novamente.',
        type: 'error'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md max-w-md mx-auto">
      <h2 className="text-2xl font-semibold mb-6 text-gray-800">Configurações de Privacidade</h2>
      
      {message && (
        <div className={`p-3 mb-4 rounded ${message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
          {message.text}
        </div>
      )}
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium text-gray-800">Status online</h3>
            <p className="text-sm text-gray-500">Quem pode ver quando você está online</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input 
              type="checkbox" 
              className="sr-only peer"
              checked={hideOnlineStatus}
              onChange={(e) => setHideOnlineStatus(e.target.checked)}
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
            <span className="ml-2 text-sm font-medium text-gray-700">
              {hideOnlineStatus ? 'Oculto' : 'Visível'}
            </span>
          </label>
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium text-gray-800">Confirmações de leitura</h3>
            <p className="text-sm text-gray-500">Mostrar quando você leu as mensagens</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input 
              type="checkbox" 
              className="sr-only peer"
              checked={hideReadReceipts}
              onChange={(e) => setHideReadReceipts(e.target.checked)}
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
            <span className="ml-2 text-sm font-medium text-gray-700">
              {hideReadReceipts ? 'Ocultas' : 'Visíveis'}
            </span>
          </label>
        </div>
        
        <div className="mt-6 pt-4 border-t border-gray-200">
          <p className="text-sm text-gray-500 mb-4">
            <strong>Nota:</strong> Ao ocultar confirmações de leitura, você também não poderá ver quando outras pessoas leram suas mensagens.
          </p>
          
          <button
            onClick={handleSave}
            className={`w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
            disabled={isLoading}
          >
            {isLoading ? 'Salvando...' : 'Salvar Configurações'}
          </button>
        </div>
      </div>
    </div>
  );
}
