'use client';

import { useState, useEffect } from 'react';
import { useChat } from '@/contexts/ChatContext';
import { useAuth } from '@/contexts/AuthContext';

export default function Header() {
  const { activeContactId, contacts } = useChat();
  const { user, logout } = useAuth();
  const [showMenu, setShowMenu] = useState(false);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  
  const activeContact = contacts.find(contact => contact.id === activeContactId);

  // Fechar menu ao clicar fora
  useEffect(() => {
    const handleClickOutside = () => {
      setShowMenu(false);
    };
    
    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  const handleMenuToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowMenu(!showMenu);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="bg-[#f0f2f5] p-3 flex justify-between items-center border-b border-gray-300">
      <div className="flex items-center">
        {activeContactId && activeContact ? (
          <>
            {/* Botão de voltar para sidebar em dispositivos móveis */}
            <button 
              className="md:hidden mr-2 text-gray-600"
              onClick={() => setShowMobileSidebar(true)}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            
            <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
              <span className="text-gray-600">{activeContact.name.charAt(0)}</span>
            </div>
            <div className="ml-3">
              <h3 className="font-semibold">{activeContact.name}</h3>
              <p className="text-xs text-gray-500">
                {activeContact.status === 'online' 
                  ? 'online' 
                  : activeContact.lastSeen}
              </p>
            </div>
          </>
        ) : (
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
              <span className="text-gray-600">{user?.name?.charAt(0) || 'U'}</span>
            </div>
            <div className="ml-3">
              <h3 className="font-semibold">{user?.name || 'Usuário'}</h3>
              <p className="text-xs text-gray-500">online</p>
            </div>
          </div>
        )}
      </div>
      
      <div className="relative">
        <button 
          className="p-1 text-gray-600"
          onClick={handleMenuToggle}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
          </svg>
        </button>
        
        {showMenu && (
          <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10">
            <div className="py-1">
              <button 
                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                onClick={handleLogout}
              >
                Sair
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
