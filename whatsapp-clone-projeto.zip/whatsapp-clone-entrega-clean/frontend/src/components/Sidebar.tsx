'use client';

import { useState } from 'react';
import { useChat } from '@/contexts/ChatContext';

export default function Sidebar() {
  const { contacts, getLastMessage, getUnreadCount, setActiveContact, activeContactId } = useChat();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredContacts = contacts.filter(contact => 
    contact.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const handleContactClick = (contactId: string) => {
    setActiveContact(contactId);
    // Para dispositivos móveis, podemos adicionar uma função para alternar a visualização
    if (window.innerWidth < 768) {
      // Esta função seria passada como prop do componente pai
      // mas como estamos apenas simulando, não precisamos implementá-la completamente
    }
  };

  return (
    <div className="w-full md:w-1/3 border-r border-gray-300 bg-white flex flex-col h-full">
      {/* Header */}
      <div className="bg-[#f0f2f5] p-3 flex justify-between items-center">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
            <span className="text-gray-600">U</span>
          </div>
        </div>
        <div className="flex space-x-4 text-gray-600">
          <button className="p-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M8 9a3 3 0 100-6 3 3 0 000 6zM8 11a6 6 0 016 6H2a6 6 0 016-6z" />
            </svg>
          </button>
          <button className="p-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-6-3a2 2 0 11-4 0 2 2 0 014 0zm-2 4a5 5 0 00-4.546 2.916A5.986 5.986 0 005 10a6 6 0 0012 0c0-.35-.035-.691-.1-1.02A5 5 0 0010 11z" clipRule="evenodd" />
            </svg>
          </button>
          <button className="p-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
            </svg>
          </button>
          <button className="p-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 000 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="p-2 bg-[#f0f2f5]">
        <div className="bg-white rounded-lg flex items-center px-3 py-1">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
          </svg>
          <input
            type="text"
            placeholder="Pesquisar ou começar uma nova conversa"
            className="ml-2 py-1 w-full outline-none text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Conversation List */}
      <div className="flex-1 overflow-y-auto">
        {filteredContacts.map((contact) => {
          const lastMessage = getLastMessage(contact.id);
          const unreadCount = getUnreadCount(contact.id);
          
          return (
            <div 
              key={contact.id} 
              className={`flex items-center p-3 border-b border-gray-200 hover:bg-gray-100 cursor-pointer ${
                activeContactId === contact.id ? 'bg-gray-200' : ''
              }`}
              onClick={() => handleContactClick(contact.id)}
            >
              <div className="relative">
                <div className="w-12 h-12 rounded-full bg-gray-300 flex items-center justify-center">
                  <span className="text-gray-600">{contact.name.charAt(0)}</span>
                </div>
                {unreadCount > 0 && (
                  <div className="absolute -top-1 -right-1 bg-green-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                    {unreadCount}
                  </div>
                )}
                {contact.status === 'online' && (
                  <div className="absolute bottom-0 right-0 bg-green-500 rounded-full w-3 h-3 border-2 border-white"></div>
                )}
              </div>
              <div className="ml-3 flex-1">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-semibold">{contact.name}</h3>
                  <span className="text-xs text-gray-500">{lastMessage?.timestamp}</span>
                </div>
                <p className="text-sm text-gray-600 truncate">
                  {lastMessage ? lastMessage.text : 'Nenhuma mensagem ainda'}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
