# Guia de Implantação do Clone do WhatsApp

Este documento descreve os passos necessários para implantar a aplicação completa do Clone do WhatsApp em um ambiente de produção.

## Pré-requisitos

- Conta no Firebase (Firestore e Storage)
- Servidor Node.js para o backend
- Plataforma para hospedagem do frontend (Vercel, Netlify, etc.)
- Domínio (opcional, mas recomendado para produção)

## 1. Configuração do Firebase

### 1.1 Firestore

1. Criar um novo projeto no Firebase Console
2. Ativar o Firestore Database
3. Configurar regras de segurança:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
      
      match /contacts/{contactId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
    
    match /conversations/{conversationId} {
      allow read, write: if request.auth != null && 
                          request.auth.uid in resource.data.participants;
      
      match /messages/{messageId} {
        allow read, write: if request.auth != null && 
                            get(/databases/$(database)/documents/conversations/$(conversationId)).data.participants[request.auth.uid] != null;
      }
    }
  }
}
```

### 1.2 Firebase Storage

1. Ativar o Firebase Storage
2. Configurar regras de segurança:

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{userId}/{type}/{filename} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    match /conversations/{conversationId}/{filename} {
      allow read: if request.auth != null && 
                   exists(/databases/$(database)/documents/conversations/$(conversationId)/participants/$(request.auth.uid));
      allow write: if request.auth != null && 
                    exists(/databases/$(database)/documents/conversations/$(conversationId)/participants/$(request.auth.uid));
    }
  }
}
```

### 1.3 Obter Credenciais

1. Ir para Configurações do Projeto > Contas de serviço
2. Gerar nova chave privada
3. Baixar o arquivo JSON com as credenciais

## 2. Implantação do Backend

### 2.1 Preparação

1. Criar arquivo `.env` na raiz do projeto backend:

```
PORT=8000
NODE_ENV=production
JWT_SECRET=seu_segredo_jwt_seguro
FRONTEND_URL=https://seu-dominio-frontend.com

# Configurações de Email (para recuperação de senha)
EMAIL_HOST=smtp.seu-provedor.com
EMAIL_PORT=587
EMAIL_USER=seu-email@exemplo.com
EMAIL_PASS=sua_senha_segura

# Firebase
FIREBASE_PROJECT_ID=seu-projeto-id
FIREBASE_PRIVATE_KEY="sua-chave-privada"
FIREBASE_CLIENT_EMAIL=seu-client-email
```

2. Criar arquivo `firebase-credentials.json` com as credenciais baixadas

### 2.2 Build

```bash
cd /home/ubuntu/whatsapp-clone/backend
npm install
npm run build
```

### 2.3 Deploy

#### Opção 1: Heroku

```bash
heroku create whatsapp-clone-backend
heroku config:set $(cat .env)
git push heroku main
```

#### Opção 2: DigitalOcean App Platform

1. Criar novo aplicativo no DigitalOcean App Platform
2. Conectar ao repositório Git
3. Configurar variáveis de ambiente a partir do arquivo `.env`
4. Implantar

#### Opção 3: Servidor VPS

```bash
# No servidor
mkdir -p /var/www/whatsapp-clone-backend
cd /var/www/whatsapp-clone-backend

# Copiar arquivos
scp -r /home/ubuntu/whatsapp-clone/backend/dist/* usuario@servidor:/var/www/whatsapp-clone-backend/
scp /home/ubuntu/whatsapp-clone/backend/package.json usuario@servidor:/var/www/whatsapp-clone-backend/
scp /home/ubuntu/whatsapp-clone/backend/.env usuario@servidor:/var/www/whatsapp-clone-backend/

# Instalar dependências
npm install --production

# Configurar PM2
pm2 start dist/server.js --name whatsapp-backend
pm2 save
pm2 startup
```

## 3. Implantação do Frontend

### 3.1 Preparação

1. Criar arquivo `.env.production` na raiz do projeto frontend:

```
NEXT_PUBLIC_API_URL=https://seu-backend-api.com/api
NEXT_PUBLIC_SOCKET_URL=https://seu-backend-api.com
```

### 3.2 Build

```bash
cd /home/ubuntu/whatsapp-clone/whatsapp-clone
npm install
npm run build
```

### 3.3 Deploy

#### Opção 1: Vercel

```bash
npm install -g vercel
vercel login
vercel --prod
```

#### Opção 2: Netlify

```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

#### Opção 3: Servidor VPS com Nginx

```bash
# No servidor
mkdir -p /var/www/whatsapp-clone-frontend
cd /var/www/whatsapp-clone-frontend

# Copiar arquivos
scp -r /home/ubuntu/whatsapp-clone/whatsapp-clone/out/* usuario@servidor:/var/www/whatsapp-clone-frontend/

# Configurar Nginx
cat > /etc/nginx/sites-available/whatsapp-clone <<EOF
server {
    listen 80;
    server_name seu-dominio.com;
    
    location / {
        root /var/www/whatsapp-clone-frontend;
        index index.html;
        try_files \$uri \$uri/ /index.html;
    }
    
    location /api {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
    
    location /socket.io {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

ln -s /etc/nginx/sites-available/whatsapp-clone /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx

# Configurar HTTPS com Certbot
apt-get update
apt-get install certbot python3-certbot-nginx
certbot --nginx -d seu-dominio.com
```

## 4. Verificação Pós-Implantação

### 4.1 Verificar Conectividade

1. Acessar o frontend pelo navegador
2. Verificar se a conexão com o backend está funcionando
3. Testar login e registro
4. Verificar se o WebSocket está conectando corretamente

### 4.2 Monitoramento

1. Configurar logs do servidor
2. Configurar alertas para erros
3. Monitorar uso de recursos (CPU, memória, disco)
4. Configurar backup regular do banco de dados

## 5. Manutenção

### 5.1 Atualizações

1. Implementar pipeline de CI/CD para atualizações automáticas
2. Manter dependências atualizadas
3. Realizar testes de regressão após atualizações

### 5.2 Backup

1. Configurar backup diário do Firestore
2. Armazenar backups em local seguro
3. Testar processo de restauração periodicamente

## 6. Escalabilidade

### 6.1 Backend

1. Configurar balanceamento de carga para múltiplas instâncias
2. Implementar cache para reduzir consultas ao banco de dados
3. Otimizar consultas frequentes

### 6.2 Frontend

1. Configurar CDN para arquivos estáticos
2. Implementar lazy loading para componentes pesados
3. Otimizar tamanho de bundle
