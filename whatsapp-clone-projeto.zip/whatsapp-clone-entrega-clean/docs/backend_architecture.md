# Arquitetura do Backend para o WhatsApp Clone

Este documento descreve a arquitetura planejada para o backend do projeto WhatsApp Clone, que visa fornecer funcionalidades de chat em tempo real, incluindo envio de mensagens de texto, imagens e áudio, além de autenticação de usuários.

## 1. Tecnologias Principais

-   **Ambiente de Execução/Framework:** Node.js com Express.js
    -   **Node.js:** Escolhido por sua natureza assíncrona e orientada a eventos, ideal para aplicações de chat em tempo real.
    -   **Express.js:** Framework minimalista e flexível para Node.js, facilitando a criação de APIs RESTful.
-   **Comunicação em Tempo Real:** Socket.IO
    -   **Socket.IO:** Biblioteca que permite comunicação bidirecional baseada em eventos em tempo real entre clientes web e um servidor. Lida bem com WebSockets e possui fallbacks para navegadores mais antigos.
-   **Linguagem de Programação:** TypeScript
    -   **TypeScript:** Adiciona tipagem estática ao JavaScript, melhorando a robustez do código, a manutenibilidade e a experiência de desenvolvimento em projetos maiores.

## 2. Banco de Dados

-   **Opção Principal:** Firestore (Google Cloud Firebase)
    -   **Motivo:** Banco de dados NoSQL, orientado a documentos, altamente escalável e com capacidades de sincronização em tempo real nativas. Integra-se bem com o ecossistema Firebase (incluindo autenticação e armazenamento, se desejado) e possui SDKs robustos para Node.js.
    -   **Alternativa:** MongoDB com Mongoose (ODM)
        -   MongoDB é outra opção NoSQL popular, e Mongoose facilitaria a modelagem dos dados.

### Esquema do Banco de Dados (Proposta Inicial com Firestore)

-   **Coleção `users`:**
    -   `userId` (string, ID único)
    -   `name` (string)
    -   `email` (string, único)
    -   `passwordHash` (string)
    -   `avatarUrl` (string, opcional)
    -   `status` (string: "online", "offline")
    -   `lastSeen` (timestamp)
    -   `contacts` (array de `userIds`)
    -   `createdAt` (timestamp)
    -   `updatedAt` (timestamp)

-   **Coleção `conversations`:**
    -   `conversationId` (string, ID único)
    -   `participants` (array de `userIds` - geralmente 2 para chats privados, mais para grupos)
    -   `type` (string: "private", "group")
    -   `lastMessage` (objeto: { `messageId`, `text`, `senderId`, `timestamp` })
    -   `createdAt` (timestamp)
    -   `updatedAt` (timestamp)
    -   `groupName` (string, se `type` for "group")
    -   `groupAvatarUrl` (string, se `type` for "group")

-   **Subcoleção `messages` (dentro de cada documento `conversation`):**
    -   `messageId` (string, ID único)
    -   `conversationId` (string, referência à conversa pai)
    -   `senderId` (string, `userId` do remetente)
    -   `type` (string: "text", "image", "audio", "emoji")
    -   `text` (string, conteúdo da mensagem de texto ou emoji)
    -   `mediaUrl` (string, URL para imagem ou áudio armazenado)
    -   `audioDuration` (number, em segundos, se `type` for "audio")
    -   `timestamp` (timestamp)
    -   `status` (objeto: { `deliveredTo`: [userIds], `readBy`: [userIds] } ou string: "sent", "delivered", "read" - a ser definido)

## 3. Armazenamento de Mídia

-   **Opção Principal:** Firebase Storage (Google Cloud Firebase)
    -   **Motivo:** Solução de armazenamento de objetos escalável, segura e simples de usar, especialmente se o Firestore já estiver sendo utilizado. Oferece boa integração com o Firebase SDK.
    -   **Alternativa:** AWS S3 (Amazon Web Services)
        -   Solução robusta e amplamente utilizada para armazenamento de objetos, mas pode adicionar complexidade de configuração se o restante da stack não estiver na AWS.

## 4. Autenticação

-   **Estratégia:** Autenticação baseada em JSON Web Tokens (JWT).
    -   O backend gerará um JWT após o login/registro bem-sucedido.
    -   O token será enviado ao cliente e armazenado de forma segura (ex: `localStorage` ou `HttpOnly cookie`).
    -   O cliente enviará o JWT no cabeçalho `Authorization` para todas as requisições protegidas.
    -   O backend validará o JWT em cada requisição.
-   **Hashing de Senhas:** Utilizar `bcrypt` para armazenar hashes de senhas de forma segura.

## 5. Estrutura da API RESTful

Principais endpoints planejados:

-   **Autenticação:**
    -   `POST /api/auth/register`
    -   `POST /api/auth/login`
    -   `POST /api/auth/logout` (pode invalidar o token no lado do servidor, se necessário)
-   **Usuários:**
    -   `GET /api/users/me` (obter perfil do usuário logado)
    -   `PUT /api/users/me` (atualizar perfil do usuário logado)
    -   `GET /api/users/search?q=<query>` (buscar usuários/contatos)
    -   `POST /api/users/contacts` (adicionar contato)
-   **Conversas:**
    -   `GET /api/conversations` (listar conversas do usuário)
    -   `POST /api/conversations` (criar nova conversa privada ou grupo)
    -   `GET /api/conversations/:conversationId/messages` (obter mensagens de uma conversa)
    -   `POST /api/conversations/:conversationId/messages` (enviar mensagem de texto)
-   **Mídia:**
    -   `POST /api/media/upload/image` (upload de imagem, retorna URL)
    -   `POST /api/media/upload/audio` (upload de áudio, retorna URL)

## 6. Eventos WebSocket (Socket.IO)

Principais eventos planejados:

-   **Conexão:**
    -   `connection`: Usuário se conecta ao servidor WebSocket após autenticação.
    -   `disconnect`: Usuário se desconecta.
-   **Mensagens:**
    -   `joinConversation (conversationId)`: Cliente entra em uma sala de conversa.
    -   `leaveConversation (conversationId)`: Cliente sai de uma sala de conversa.
    -   `sendMessage (messageData)`: Cliente envia uma nova mensagem.
    -   `newMessage (messageData)`: Servidor envia nova mensagem para os participantes da conversa.
-   **Status do Usuário:**
    -   `userOnline (userId)`: Notifica que um usuário ficou online.
    -   `userOffline (userId, lastSeen)`: Notifica que um usuário ficou offline.
    -   `typing (conversationId, userId)`: Notifica que um usuário está digitando.
    -   `stopTyping (conversationId, userId)`: Notifica que um usuário parou de digitar.
-   **Status da Mensagem:**
    -   `messageDelivered (messageId, userId)`: Notifica que uma mensagem foi entregue.
    -   `messageRead (messageId, userId, conversationId)`: Notifica que uma mensagem foi lida.

## 7. Considerações Adicionais

-   **Validação de Dados:** Utilizar bibliotecas como `Joi` ou `express-validator` para validar os dados de entrada nas rotas da API.
-   **Tratamento de Erros:** Implementar um middleware de tratamento de erros centralizado.
-   **Segurança:** Considerar medidas de segurança como HTTPS, proteção contra CSRF, XSS, e rate limiting.
-   **Escalabilidade:** A escolha do Firestore e Firebase Storage já considera a escalabilidade. A arquitetura do Node.js também é escalável horizontalmente.

Este plano de arquitetura servirá como base para o desenvolvimento do backend. Ele poderá ser refinado e ajustado conforme o desenvolvimento avança.
