import { Request, Response } from 'express';
import { db } from '../config/firebase';
import { Conversation, Message } from '../models/user.model';
import { firestore } from 'firebase-admin';

// Obter todas as conversas do usuário
export const getConversations = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    // Buscar conversas onde o usuário é participante
    const conversationsRef = db.collection('conversations')
      .where('participants', 'array-contains', userId);
    
    const snapshot = await conversationsRef.get();
    
    if (snapshot.empty) {
      return res.status(200).json({ conversations: [] });
    }

    const conversations = snapshot.docs.map(doc => {
      const data = doc.data() as Conversation;
      return {
        id: doc.id,
        ...data,
        // Converter timestamps do Firestore para formato de data
        createdAt: data.createdAt instanceof firestore.Timestamp 
          ? data.createdAt.toDate() 
          : data.createdAt,
        updatedAt: data.updatedAt instanceof firestore.Timestamp 
          ? data.updatedAt.toDate() 
          : data.updatedAt,
        lastMessage: data.lastMessage ? {
          ...data.lastMessage,
          timestamp: data.lastMessage.timestamp instanceof firestore.Timestamp 
            ? data.lastMessage.timestamp.toDate() 
            : data.lastMessage.timestamp
        } : undefined
      };
    });

    res.status(200).json({ conversations });
  } catch (error) {
    console.error('Erro ao buscar conversas:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao buscar conversas.' });
  }
};

// Obter uma conversa específica por ID
export const getConversationById = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    const { conversationId } = req.params;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    const conversationRef = db.collection('conversations').doc(conversationId);
    const doc = await conversationRef.get();
    
    if (!doc.exists) {
      return res.status(404).json({ message: 'Conversa não encontrada.' });
    }

    const conversation = doc.data() as Conversation;
    
    // Verificar se o usuário é participante da conversa
    if (!conversation.participants.includes(userId)) {
      return res.status(403).json({ message: 'Acesso negado a esta conversa.' });
    }

    // Converter timestamps
    const formattedConversation = {
      id: doc.id,
      ...conversation,
      createdAt: conversation.createdAt instanceof firestore.Timestamp 
        ? conversation.createdAt.toDate() 
        : conversation.createdAt,
      updatedAt: conversation.updatedAt instanceof firestore.Timestamp 
        ? conversation.updatedAt.toDate() 
        : conversation.updatedAt,
      lastMessage: conversation.lastMessage ? {
        ...conversation.lastMessage,
        timestamp: conversation.lastMessage.timestamp instanceof firestore.Timestamp 
          ? conversation.lastMessage.timestamp.toDate() 
          : conversation.lastMessage.timestamp
      } : undefined
    };

    res.status(200).json({ conversation: formattedConversation });
  } catch (error) {
    console.error('Erro ao buscar conversa:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao buscar conversa.' });
  }
};

// Criar uma nova conversa
export const createConversation = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    const { participantIds, type, groupName, groupAvatarUrl } = req.body;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    // Validar dados da requisição
    if (!participantIds || !Array.isArray(participantIds)) {
      return res.status(400).json({ message: 'Lista de participantes é obrigatória.' });
    }

    if (type !== 'private' && type !== 'group') {
      return res.status(400).json({ message: 'Tipo de conversa inválido. Deve ser "private" ou "group".' });
    }

    // Para conversas privadas, deve haver exatamente 2 participantes
    if (type === 'private' && participantIds.length !== 1) {
      return res.status(400).json({ message: 'Conversas privadas devem ter exatamente 1 participante além de você.' });
    }

    // Para grupos, deve haver pelo menos 2 participantes (além do criador)
    if (type === 'group' && participantIds.length < 2) {
      return res.status(400).json({ message: 'Grupos devem ter pelo menos 2 participantes além de você.' });
    }

    // Para grupos, nome é obrigatório
    if (type === 'group' && !groupName) {
      return res.status(400).json({ message: 'Nome do grupo é obrigatório.' });
    }

    // Verificar se os participantes existem
    const participantsToCheck = [...participantIds];
    if (!participantsToCheck.includes(userId)) {
      participantsToCheck.push(userId);
    }

    const usersRef = db.collection('users');
    const userPromises = participantsToCheck.map(id => usersRef.doc(id).get());
    const userDocs = await Promise.all(userPromises);
    
    const invalidUsers = userDocs.filter(doc => !doc.exists);
    if (invalidUsers.length > 0) {
      return res.status(400).json({ message: 'Um ou mais participantes não existem.' });
    }

    // Para conversas privadas, verificar se já existe uma conversa entre os mesmos participantes
    if (type === 'private') {
      const allParticipants = [userId, ...participantIds];
      const existingConversationRef = db.collection('conversations')
        .where('type', '==', 'private')
        .where('participants', 'array-contains', userId);
      
      const existingConversations = await existingConversationRef.get();
      
      const existingConversation = existingConversations.docs.find(doc => {
        const data = doc.data() as Conversation;
        return data.participants.length === 2 && 
               data.participants.includes(participantIds[0]);
      });

      if (existingConversation) {
        const conversationData = existingConversation.data() as Conversation;
        return res.status(200).json({ 
          message: 'Conversa já existe.',
          conversation: {
            id: existingConversation.id,
            ...conversationData,
            createdAt: conversationData.createdAt instanceof firestore.Timestamp 
              ? conversationData.createdAt.toDate() 
              : conversationData.createdAt,
            updatedAt: conversationData.updatedAt instanceof firestore.Timestamp 
              ? conversationData.updatedAt.toDate() 
              : conversationData.updatedAt,
          }
        });
      }
    }

    // Criar nova conversa
    const newConversation: Omit<Conversation, 'id'> = {
      participants: [userId, ...participantIds],
      type,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Adicionar campos específicos para grupos
    if (type === 'group') {
      newConversation.groupName = groupName;
      if (groupAvatarUrl) {
        newConversation.groupAvatarUrl = groupAvatarUrl;
      }
    }

    const conversationRef = await db.collection('conversations').add(newConversation);
    
    res.status(201).json({ 
      message: 'Conversa criada com sucesso!',
      conversation: {
        id: conversationRef.id,
        ...newConversation
      }
    });
  } catch (error) {
    console.error('Erro ao criar conversa:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao criar conversa.' });
  }
};

// Obter mensagens de uma conversa
export const getConversationMessages = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    const { conversationId } = req.params;
    const { limit = 50, before } = req.query;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    // Verificar se a conversa existe e se o usuário é participante
    const conversationRef = db.collection('conversations').doc(conversationId);
    const conversationDoc = await conversationRef.get();
    
    if (!conversationDoc.exists) {
      return res.status(404).json({ message: 'Conversa não encontrada.' });
    }

    const conversation = conversationDoc.data() as Conversation;
    if (!conversation.participants.includes(userId)) {
      return res.status(403).json({ message: 'Acesso negado a esta conversa.' });
    }

    // Construir a query para buscar mensagens
    let messagesQuery = db.collection('conversations')
      .doc(conversationId)
      .collection('messages')
      .orderBy('timestamp', 'desc')
      .limit(Number(limit));
    
    // Se 'before' for fornecido, paginar a partir desse timestamp
    if (before) {
      const beforeDate = new Date(before as string);
      messagesQuery = messagesQuery.where('timestamp', '<', beforeDate);
    }

    const messagesSnapshot = await messagesQuery.get();
    
    const messages = messagesSnapshot.docs.map(doc => {
      const data = doc.data() as Message;
      return {
        id: doc.id,
        ...data,
        timestamp: data.timestamp instanceof firestore.Timestamp 
          ? data.timestamp.toDate() 
          : data.timestamp
      };
    });

    // Marcar mensagens como lidas (opcional, pode ser feito via WebSocket)
    const unreadMessages = messages.filter(msg => 
      msg.senderId !== userId && 
      !msg.status.readBy.includes(userId)
    );

    if (unreadMessages.length > 0) {
      const batch = db.batch();
      
      unreadMessages.forEach(msg => {
        const msgRef = db.collection('conversations')
          .doc(conversationId)
          .collection('messages')
          .doc(msg.id);
        
        batch.update(msgRef, {
          'status.readBy': firestore.FieldValue.arrayUnion(userId)
        });
      });

      await batch.commit();
    }

    res.status(200).json({ messages: messages.reverse() }); // Reverter para ordem cronológica
  } catch (error) {
    console.error('Erro ao buscar mensagens:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao buscar mensagens.' });
  }
};

// Enviar uma nova mensagem
export const sendMessage = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    const { conversationId } = req.params;
    const { text, type = 'text', mediaUrl, audioDuration } = req.body;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    // Validar dados da requisição
    if (!text && !mediaUrl) {
      return res.status(400).json({ message: 'Texto ou URL de mídia é obrigatório.' });
    }

    if (!['text', 'image', 'audio', 'emoji'].includes(type)) {
      return res.status(400).json({ message: 'Tipo de mensagem inválido.' });
    }

    if ((type === 'image' || type === 'audio') && !mediaUrl) {
      return res.status(400).json({ message: 'URL de mídia é obrigatório para mensagens de imagem ou áudio.' });
    }

    if (type === 'audio' && !audioDuration) {
      return res.status(400).json({ message: 'Duração é obrigatória para mensagens de áudio.' });
    }

    // Verificar se a conversa existe e se o usuário é participante
    const conversationRef = db.collection('conversations').doc(conversationId);
    const conversationDoc = await conversationRef.get();
    
    if (!conversationDoc.exists) {
      return res.status(404).json({ message: 'Conversa não encontrada.' });
    }

    const conversation = conversationDoc.data() as Conversation;
    if (!conversation.participants.includes(userId)) {
      return res.status(403).json({ message: 'Acesso negado a esta conversa.' });
    }

    // Criar nova mensagem
    const timestamp = new Date();
    const newMessage: Omit<Message, 'id'> = {
      conversationId,
      senderId: userId,
      type,
      timestamp,
      status: {
        deliveredTo: [userId], // Inicialmente entregue apenas ao remetente
        readBy: [userId]       // Inicialmente lida apenas pelo remetente
      }
    };

    // Adicionar campos específicos por tipo de mensagem
    if (text) {
      newMessage.text = text;
    }

    if (mediaUrl) {
      newMessage.mediaUrl = mediaUrl;
    }

    if (type === 'audio' && audioDuration) {
      newMessage.audioDuration = audioDuration;
    }

    // Salvar a mensagem
    const messageRef = await db.collection('conversations')
      .doc(conversationId)
      .collection('messages')
      .add(newMessage);

    // Atualizar lastMessage na conversa
    await conversationRef.update({
      lastMessage: {
        messageId: messageRef.id,
        text: text || `[${type.toUpperCase()}]`,
        senderId: userId,
        timestamp
      },
      updatedAt: timestamp
    });

    // Retornar a mensagem criada
    const createdMessage = {
      id: messageRef.id,
      ...newMessage
    };

    res.status(201).json({ 
      message: 'Mensagem enviada com sucesso!',
      data: createdMessage
    });

    // Nota: Em uma implementação real, aqui você emitiria um evento via Socket.IO
    // para notificar os outros participantes da conversa sobre a nova mensagem
    // Isso será implementado na parte de WebSockets

  } catch (error) {
    console.error('Erro ao enviar mensagem:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao enviar mensagem.' });
  }
};
