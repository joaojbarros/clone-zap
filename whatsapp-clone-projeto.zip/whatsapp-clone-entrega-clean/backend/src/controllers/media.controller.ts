import { Request, Response } from 'express';
import { storage } from '../config/firebase';
import { v4 as uuidv4 } from 'uuid';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import os from 'os';

// Configuração do multer para armazenamento temporário
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, os.tmpdir());
    },
    filename: (req, file, cb) => {
      cb(null, `${Date.now()}-${file.originalname}`);
    }
  }),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limite de tamanho
  },
  fileFilter: (req, file, cb) => {
    // Verificar tipos de arquivo permitidos
    if (file.fieldname === 'image') {
      const filetypes = /jpeg|jpg|png|gif|webp/;
      const mimetype = filetypes.test(file.mimetype);
      const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
      
      if (mimetype && extname) {
        return cb(null, true);
      }
      cb(new Error('Apenas imagens são permitidas (jpeg, jpg, png, gif, webp)'));
    } else if (file.fieldname === 'audio') {
      const filetypes = /mp3|wav|ogg|m4a/;
      const mimetype = filetypes.test(file.mimetype);
      const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
      
      if (mimetype && extname) {
        return cb(null, true);
      }
      cb(new Error('Apenas áudios são permitidos (mp3, wav, ogg, m4a)'));
    } else {
      cb(new Error('Tipo de arquivo não suportado'));
    }
  }
});

// Middleware para upload de imagem
export const uploadImageMiddleware = upload.single('image');

// Middleware para upload de áudio
export const uploadAudioMiddleware = upload.single('audio');

// Controlador para upload de imagem
export const uploadImage = async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Nenhum arquivo enviado.' });
    }

    const userId = req.user?.userId;
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    // Gerar nome único para o arquivo
    const fileExtension = path.extname(req.file.originalname);
    const fileName = `${userId}/images/${uuidv4()}${fileExtension}`;

    // Upload para o Firebase Storage
    const fileBuffer = fs.readFileSync(req.file.path);
    const fileUpload = storage.file(fileName);
    
    await fileUpload.save(fileBuffer, {
      metadata: {
        contentType: req.file.mimetype,
        metadata: {
          originalName: req.file.originalname,
          uploadedBy: userId,
          uploadedAt: new Date().toISOString()
        }
      }
    });

    // Configurar acesso público (ou usar token de acesso temporário em produção)
    await fileUpload.makePublic();

    // Obter URL pública
    const mediaUrl = `https://storage.googleapis.com/${storage.name}/${fileName}`;

    // Remover arquivo temporário
    fs.unlinkSync(req.file.path);

    res.status(200).json({
      message: 'Imagem enviada com sucesso!',
      mediaUrl,
      type: 'image'
    });
  } catch (error) {
    console.error('Erro ao fazer upload de imagem:', error);
    
    // Remover arquivo temporário em caso de erro
    if (req.file && req.file.path) {
      try {
        fs.unlinkSync(req.file.path);
      } catch (unlinkError) {
        console.error('Erro ao remover arquivo temporário:', unlinkError);
      }
    }
    
    res.status(500).json({ message: 'Erro interno do servidor ao fazer upload de imagem.' });
  }
};

// Controlador para upload de áudio
export const uploadAudio = async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Nenhum arquivo enviado.' });
    }

    const userId = req.user?.userId;
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    // Obter duração do áudio (deve ser enviada no corpo da requisição)
    const { duration } = req.body;
    if (!duration || isNaN(Number(duration))) {
      return res.status(400).json({ message: 'Duração do áudio é obrigatória e deve ser um número.' });
    }

    // Gerar nome único para o arquivo
    const fileExtension = path.extname(req.file.originalname);
    const fileName = `${userId}/audios/${uuidv4()}${fileExtension}`;

    // Upload para o Firebase Storage
    const fileBuffer = fs.readFileSync(req.file.path);
    const fileUpload = storage.file(fileName);
    
    await fileUpload.save(fileBuffer, {
      metadata: {
        contentType: req.file.mimetype,
        metadata: {
          originalName: req.file.originalname,
          uploadedBy: userId,
          uploadedAt: new Date().toISOString(),
          duration: Number(duration)
        }
      }
    });

    // Configurar acesso público (ou usar token de acesso temporário em produção)
    await fileUpload.makePublic();

    // Obter URL pública
    const mediaUrl = `https://storage.googleapis.com/${storage.name}/${fileName}`;

    // Remover arquivo temporário
    fs.unlinkSync(req.file.path);

    res.status(200).json({
      message: 'Áudio enviado com sucesso!',
      mediaUrl,
      type: 'audio',
      audioDuration: Number(duration)
    });
  } catch (error) {
    console.error('Erro ao fazer upload de áudio:', error);
    
    // Remover arquivo temporário em caso de erro
    if (req.file && req.file.path) {
      try {
        fs.unlinkSync(req.file.path);
      } catch (unlinkError) {
        console.error('Erro ao remover arquivo temporário:', unlinkError);
      }
    }
    
    res.status(500).json({ message: 'Erro interno do servidor ao fazer upload de áudio.' });
  }
};
