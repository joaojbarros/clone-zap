import { Request, Response } from 'express';
import { db } from '../config/firebase';
import { User } from '../models/user.model';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'seuSuperSegredo';
const EMAIL_USER = process.env.EMAIL_USER;
const EMAIL_PASS = process.env.EMAIL_PASS;
const EMAIL_HOST = process.env.EMAIL_HOST || 'smtp.gmail.com';
const EMAIL_PORT = parseInt(process.env.EMAIL_PORT || '587');
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:3000';

// Armazenamento temporário de códigos de recuperação
// Em produção, isso deveria ser armazenado em um banco de dados
const resetCodes: Record<string, { code: string; expires: Date }> = {};

// Configuração do transportador de email
const transporter = nodemailer.createTransport({
  host: EMAIL_HOST,
  port: EMAIL_PORT,
  secure: EMAIL_PORT === 465,
  auth: {
    user: EMAIL_USER,
    pass: EMAIL_PASS
  }
});

// Registrar um novo usuário
export const register = async (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body;
    
    // Validar dados
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Nome, email e senha são obrigatórios.' });
    }
    
    if (name.length < 3) {
      return res.status(400).json({ message: 'Nome deve ter pelo menos 3 caracteres.' });
    }
    
    // Validar formato de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: 'Formato de email inválido.' });
    }
    
    // Validar senha
    if (password.length < 8) {
      return res.status(400).json({ message: 'Senha deve ter pelo menos 8 caracteres.' });
    }
    
    // Verificar se o email já está em uso
    const usersRef = db.collection('users');
    const snapshot = await usersRef.where('email', '==', email).get();
    
    if (!snapshot.empty) {
      return res.status(400).json({ message: 'Este email já está em uso.' });
    }
    
    // Hash da senha
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);
    
    // Criar novo usuário
    const newUser: Omit<User, 'id'> = {
      name,
      email,
      passwordHash,
      createdAt: new Date(),
      updatedAt: new Date(),
      status: 'offline',
      lastSeen: new Date(),
      contacts: [],
      privacySettings: {
        hideOnlineStatus: false,
        hideReadReceipts: false
      }
    };
    
    // Salvar no banco de dados
    const userRef = await usersRef.add(newUser);
    
    // Gerar token JWT
    const token = jwt.sign(
      { userId: userRef.id, email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    // Retornar dados do usuário (sem a senha)
    const { passwordHash: _, ...userData } = newUser;
    
    res.status(201).json({
      message: 'Usuário registrado com sucesso!',
      token,
      user: {
        id: userRef.id,
        ...userData
      }
    });
  } catch (error) {
    console.error('Erro ao registrar usuário:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao registrar usuário.' });
  }
};

// Login de usuário
export const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    
    // Validar dados
    if (!email || !password) {
      return res.status(400).json({ message: 'Email e senha são obrigatórios.' });
    }
    
    // Buscar usuário pelo email
    const usersRef = db.collection('users');
    const snapshot = await usersRef.where('email', '==', email).get();
    
    if (snapshot.empty) {
      return res.status(401).json({ message: 'Credenciais inválidas.' });
    }
    
    // Obter dados do usuário
    const userDoc = snapshot.docs[0];
    const userData = userDoc.data() as User;
    
    // Verificar senha
    const isPasswordValid = await bcrypt.compare(password, userData.passwordHash);
    
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Credenciais inválidas.' });
    }
    
    // Gerar token JWT
    const token = jwt.sign(
      { userId: userDoc.id, email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    // Atualizar status para online
    await userDoc.ref.update({
      status: 'online',
      lastSeen: new Date()
    });
    
    // Retornar dados do usuário (sem a senha)
    const { passwordHash, ...userDataWithoutPassword } = userData;
    
    res.status(200).json({
      message: 'Login realizado com sucesso!',
      token,
      user: {
        id: userDoc.id,
        ...userDataWithoutPassword
      }
    });
  } catch (error) {
    console.error('Erro ao fazer login:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao fazer login.' });
  }
};

// Solicitar redefinição de senha
export const requestPasswordReset = async (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ message: 'Email é obrigatório.' });
    }
    
    // Buscar usuário pelo email
    const usersRef = db.collection('users');
    const snapshot = await usersRef.where('email', '==', email).get();
    
    if (snapshot.empty) {
      // Por segurança, não informamos que o email não existe
      return res.status(200).json({ message: 'Se o email estiver cadastrado, você receberá um código de recuperação.' });
    }
    
    // Gerar código de recuperação (6 dígitos)
    const resetCode = crypto.randomInt(100000, 999999).toString();
    
    // Armazenar código com expiração (10 minutos)
    const expirationTime = new Date();
    expirationTime.setMinutes(expirationTime.getMinutes() + 10);
    
    resetCodes[email] = {
      code: resetCode,
      expires: expirationTime
    };
    
    // Enviar email com código
    const mailOptions = {
      from: `"WhatsApp Clone" <${EMAIL_USER}>`,
      to: email,
      subject: 'Recuperação de Senha - WhatsApp Clone',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #128C7E;">Recuperação de Senha - WhatsApp Clone</h2>
          <p>Você solicitou a recuperação de senha para sua conta no WhatsApp Clone.</p>
          <p>Use o código abaixo para redefinir sua senha:</p>
          <div style="background-color: #f2f2f2; padding: 10px; text-align: center; font-size: 24px; letter-spacing: 5px; margin: 20px 0;">
            <strong>${resetCode}</strong>
          </div>
          <p>Este código expira em 10 minutos.</p>
          <p>Se você não solicitou esta recuperação, ignore este email.</p>
          <p>Atenciosamente,<br>Equipe WhatsApp Clone</p>
        </div>
      `
    };
    
    // Enviar email (simulado em ambiente de desenvolvimento)
    if (process.env.NODE_ENV === 'production' && EMAIL_USER && EMAIL_PASS) {
      await transporter.sendMail(mailOptions);
    } else {
      // Em desenvolvimento, apenas logamos o código
      console.log(`Código de recuperação para ${email}: ${resetCode}`);
    }
    
    res.status(200).json({ message: 'Se o email estiver cadastrado, você receberá um código de recuperação.' });
  } catch (error) {
    console.error('Erro ao solicitar redefinição de senha:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao solicitar redefinição de senha.' });
  }
};

// Verificar código de recuperação
export const verifyResetCode = async (req: Request, res: Response) => {
  try {
    const { email, code } = req.body;
    
    if (!email || !code) {
      return res.status(400).json({ message: 'Email e código são obrigatórios.' });
    }
    
    // Verificar se existe um código para este email
    const resetData = resetCodes[email];
    
    if (!resetData) {
      return res.status(400).json({ message: 'Código inválido ou expirado.' });
    }
    
    // Verificar se o código está correto
    if (resetData.code !== code) {
      return res.status(400).json({ message: 'Código inválido.' });
    }
    
    // Verificar se o código expirou
    if (new Date() > resetData.expires) {
      delete resetCodes[email];
      return res.status(400).json({ message: 'Código expirado.' });
    }
    
    res.status(200).json({ message: 'Código verificado com sucesso.' });
  } catch (error) {
    console.error('Erro ao verificar código de recuperação:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao verificar código de recuperação.' });
  }
};

// Redefinir senha
export const resetPassword = async (req: Request, res: Response) => {
  try {
    const { email, code, newPassword } = req.body;
    
    if (!email || !code || !newPassword) {
      return res.status(400).json({ message: 'Email, código e nova senha são obrigatórios.' });
    }
    
    // Verificar se existe um código para este email
    const resetData = resetCodes[email];
    
    if (!resetData) {
      return res.status(400).json({ message: 'Código inválido ou expirado.' });
    }
    
    // Verificar se o código está correto
    if (resetData.code !== code) {
      return res.status(400).json({ message: 'Código inválido.' });
    }
    
    // Verificar se o código expirou
    if (new Date() > resetData.expires) {
      delete resetCodes[email];
      return res.status(400).json({ message: 'Código expirado.' });
    }
    
    // Validar nova senha
    if (newPassword.length < 8) {
      return res.status(400).json({ message: 'Nova senha deve ter pelo menos 8 caracteres.' });
    }
    
    // Buscar usuário pelo email
    const usersRef = db.collection('users');
    const snapshot = await usersRef.where('email', '==', email).get();
    
    if (snapshot.empty) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }
    
    // Hash da nova senha
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(newPassword, salt);
    
    // Atualizar senha no banco de dados
    const userDoc = snapshot.docs[0];
    await userDoc.ref.update({
      passwordHash,
      updatedAt: new Date()
    });
    
    // Remover código de recuperação
    delete resetCodes[email];
    
    res.status(200).json({ message: 'Senha redefinida com sucesso!' });
  } catch (error) {
    console.error('Erro ao redefinir senha:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao redefinir senha.' });
  }
};
