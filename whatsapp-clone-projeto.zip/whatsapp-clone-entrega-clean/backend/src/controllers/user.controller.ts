import { Request, Response } from 'express';
import { db, storage } from '../config/firebase';
import { User } from '../models/user.model';
import bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import os from 'os';

// Configuração do multer para armazenamento temporário de avatares
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, os.tmpdir());
    },
    filename: (req, file, cb) => {
      cb(null, `${Date.now()}-${file.originalname}`);
    }
  }),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limite de tamanho
  },
  fileFilter: (req, file, cb) => {
    // Verificar tipos de arquivo permitidos para avatar
    const filetypes = /jpeg|jpg|png|gif|webp/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Apenas imagens são permitidas para avatar (jpeg, jpg, png, gif, webp)'));
  }
});

// Middleware para upload de avatar
export const uploadAvatarMiddleware = upload.single('avatar');

// Obter perfil do usuário atual
export const getUserProfile = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    const userDoc = await db.collection('users').doc(userId).get();
    
    if (!userDoc.exists) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    const userData = userDoc.data() as User;
    
    // Remover dados sensíveis
    const { passwordHash, ...userProfile } = userData;
    
    res.status(200).json({ 
      user: { 
        id: userId, 
        ...userProfile 
      } 
    });
  } catch (error) {
    console.error('Erro ao obter perfil do usuário:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao obter perfil do usuário.' });
  }
};

// Atualizar perfil do usuário atual
export const updateUserProfile = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    const { name, email, privacySettings } = req.body;
    const updateData: any = {};
    
    // Validar dados
    if (name) {
      if (name.length < 3) {
        return res.status(400).json({ message: 'Nome deve ter pelo menos 3 caracteres.' });
      }
      updateData.name = name;
    }
    
    if (email) {
      // Verificar formato de email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ message: 'Formato de email inválido.' });
      }
      
      // Verificar se o email já está em uso por outro usuário
      const emailCheck = await db.collection('users')
        .where('email', '==', email)
        .get();
      
      if (!emailCheck.empty && emailCheck.docs[0].id !== userId) {
        return res.status(400).json({ message: 'Este email já está em uso por outro usuário.' });
      }
      
      updateData.email = email;
    }
    
    // Atualizar configurações de privacidade
    if (privacySettings) {
      updateData.privacySettings = privacySettings;
    }
    
    // Verificar se há avatar para upload
    if (req.file) {
      // Upload do avatar para o Firebase Storage
      const fileExtension = path.extname(req.file.originalname);
      const fileName = `${userId}/avatar/${uuidv4()}${fileExtension}`;
      const fileBuffer = fs.readFileSync(req.file.path);
      const fileUpload = storage.file(fileName);
      
      await fileUpload.save(fileBuffer, {
        metadata: {
          contentType: req.file.mimetype,
          metadata: {
            originalName: req.file.originalname,
            uploadedBy: userId,
            uploadedAt: new Date().toISOString()
          }
        }
      });
      
      // Configurar acesso público
      await fileUpload.makePublic();
      
      // Obter URL pública
      const avatarUrl = `https://storage.googleapis.com/${storage.name}/${fileName}`;
      
      // Adicionar URL do avatar aos dados de atualização
      updateData.avatarUrl = avatarUrl;
      
      // Remover arquivo temporário
      fs.unlinkSync(req.file.path);
    }
    
    // Se não há dados para atualizar
    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({ message: 'Nenhum dado fornecido para atualização.' });
    }
    
    // Adicionar timestamp de atualização
    updateData.updatedAt = new Date();
    
    // Atualizar perfil no banco de dados
    await db.collection('users').doc(userId).update(updateData);
    
    // Obter perfil atualizado
    const updatedUserDoc = await db.collection('users').doc(userId).get();
    const updatedUserData = updatedUserDoc.data() as User;
    
    // Remover dados sensíveis
    const { passwordHash, ...updatedUserProfile } = updatedUserData;
    
    res.status(200).json({ 
      message: 'Perfil atualizado com sucesso!',
      user: { 
        id: userId, 
        ...updatedUserProfile 
      } 
    });
  } catch (error) {
    console.error('Erro ao atualizar perfil do usuário:', error);
    
    // Remover arquivo temporário em caso de erro
    if (req.file && req.file.path) {
      try {
        fs.unlinkSync(req.file.path);
      } catch (unlinkError) {
        console.error('Erro ao remover arquivo temporário:', unlinkError);
      }
    }
    
    res.status(500).json({ message: 'Erro interno do servidor ao atualizar perfil do usuário.' });
  }
};

// Buscar usuários
export const searchUsers = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    const { q } = req.query;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    if (!q || typeof q !== 'string') {
      return res.status(400).json({ message: 'Termo de busca é obrigatório.' });
    }

    // Buscar usuários que correspondam ao termo de busca
    const usersRef = db.collection('users');
    const snapshot = await usersRef.get();
    
    const users = snapshot.docs
      .map(doc => {
        const data = doc.data() as User;
        return {
          id: doc.id,
          name: data.name,
          email: data.email,
          avatarUrl: data.avatarUrl,
          status: data.status,
          lastSeen: data.lastSeen,
          privacySettings: data.privacySettings
        };
      })
      .filter(user => 
        // Excluir o próprio usuário
        user.id !== userId && 
        // Filtrar por nome ou email
        (user.name.toLowerCase().includes(q.toLowerCase()) || 
         user.email.toLowerCase().includes(q.toLowerCase()))
      )
      // Limitar a 20 resultados
      .slice(0, 20);
    
    res.status(200).json({ users });
  } catch (error) {
    console.error('Erro ao buscar usuários:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao buscar usuários.' });
  }
};

// Adicionar contato
export const addContact = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    const { contactId } = req.body;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    if (!contactId) {
      return res.status(400).json({ message: 'ID do contato é obrigatório.' });
    }

    // Verificar se o contato existe
    const contactDoc = await db.collection('users').doc(contactId).get();
    
    if (!contactDoc.exists) {
      return res.status(404).json({ message: 'Contato não encontrado.' });
    }

    // Verificar se o contato já está na lista
    const userDoc = await db.collection('users').doc(userId).get();
    const userData = userDoc.data() as User;
    
    if (userData.contacts && userData.contacts.includes(contactId)) {
      return res.status(400).json({ message: 'Este contato já está na sua lista.' });
    }

    // Adicionar contato à lista
    await db.collection('users').doc(userId).update({
      contacts: userData.contacts ? [...userData.contacts, contactId] : [contactId],
      updatedAt: new Date()
    });

    // Obter dados do contato
    const contactData = contactDoc.data() as User;
    
    res.status(200).json({ 
      message: 'Contato adicionado com sucesso!',
      contact: {
        id: contactId,
        name: contactData.name,
        email: contactData.email,
        avatarUrl: contactData.avatarUrl,
        status: contactData.status,
        lastSeen: contactData.lastSeen,
        privacySettings: contactData.privacySettings
      }
    });
  } catch (error) {
    console.error('Erro ao adicionar contato:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao adicionar contato.' });
  }
};

// Obter contatos do usuário
export const getUserContacts = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    
    if (!userId) {
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    // Obter lista de contatos do usuário
    const userDoc = await db.collection('users').doc(userId).get();
    
    if (!userDoc.exists) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    const userData = userDoc.data() as User;
    
    if (!userData.contacts || userData.contacts.length === 0) {
      return res.status(200).json({ contacts: [] });
    }

    // Obter dados de cada contato
    const contactPromises = userData.contacts.map(contactId => 
      db.collection('users').doc(contactId).get()
    );
    
    const contactDocs = await Promise.all(contactPromises);
    
    const contacts = contactDocs
      .filter(doc => doc.exists)
      .map(doc => {
        const data = doc.data() as User;
        
        // Verificar configurações de privacidade
        const showStatus = !data.privacySettings?.hideOnlineStatus;
        
        return {
          id: doc.id,
          name: data.name,
          email: data.email,
          avatarUrl: data.avatarUrl,
          status: showStatus ? data.status : 'offline',
          lastSeen: showStatus ? data.lastSeen : null,
          privacySettings: data.privacySettings
        };
      });
    
    res.status(200).json({ contacts });
  } catch (error) {
    console.error('Erro ao obter contatos do usuário:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao obter contatos do usuário.' });
  }
};
