import { Router } from 'express';
import { authMiddleware } from '../middlewares/auth.middleware';
import { 
  getConversations,
  getConversationById,
  createConversation,
  getConversationMessages,
  sendMessage
} from '../controllers/conversation.controller';

const router = Router();

// Todas as rotas de conversas requerem autenticação
router.use(authMiddleware);

// Rotas para gerenciamento de conversas
router.get('/', getConversations);
router.get('/:conversationId', getConversationById);
router.post('/', createConversation);

// Rotas para mensagens dentro de conversas
router.get('/:conversationId/messages', getConversationMessages);
router.post('/:conversationId/messages', sendMessage);

export default router;
