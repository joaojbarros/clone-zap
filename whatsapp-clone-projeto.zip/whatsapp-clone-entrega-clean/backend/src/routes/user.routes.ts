import { Router } from 'express';
import { authMiddleware } from '../middlewares/auth.middleware';
import { 
  getUserProfile, 
  updateUserProfile, 
  searchUsers, 
  addContact, 
  getUserContacts 
} from '../controllers/user.controller';

const router = Router();

// Todas as rotas de usuário requerem autenticação
router.use(authMiddleware);

// Rotas para perfil do usuário
router.get('/me', getUserProfile);
router.put('/me', updateUserProfile);

// Rotas para busca e gerenciamento de contatos
router.get('/search', searchUsers);
router.post('/contacts', addContact);
router.get('/contacts', getUserContacts);

export default router;
