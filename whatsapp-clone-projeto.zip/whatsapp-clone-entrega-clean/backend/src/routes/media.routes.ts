import { Router } from 'express';
import { authMiddleware } from '../middlewares/auth.middleware';
import { uploadImage, uploadAudio } from '../controllers/media.controller';

const router = Router();

// Todas as rotas de mídia requerem autenticação
router.use(authMiddleware);

// Rotas para upload de mídia
router.post('/upload/image', uploadImage);
router.post('/upload/audio', uploadAudio);

export default router;
