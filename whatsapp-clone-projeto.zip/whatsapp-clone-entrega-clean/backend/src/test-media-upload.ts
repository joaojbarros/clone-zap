// Arquivo para testar o upload de mídia
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import axios from 'axios';
import FormData from 'form-data';

dotenv.config();

const API_URL = process.env.API_URL || 'http://localhost:8000/api';
let authToken = '';

// Função para fazer login e obter token
async function login() {
  try {
    const response = await axios.post(`${API_URL}/auth/login`, {
      email: 'teste@email.com',
      password: 'senha123'
    });
    
    authToken = response.data.token;
    console.log('Login bem-sucedido!');
    return true;
  } catch (error) {
    console.error('Erro ao fazer login:', error.response?.data || error.message);
    
    // Se o usuário não existir, tente registrar
    return await register();
  }
}

// Função para registrar um usuário de teste
async function register() {
  try {
    const response = await axios.post(`${API_URL}/auth/register`, {
      name: 'Usuário Teste',
      email: 'teste@email.com',
      password: 'senha123'
    });
    
    authToken = response.data.token;
    console.log('Registro bem-sucedido!');
    return true;
  } catch (error) {
    console.error('Erro ao registrar:', error.response?.data || error.message);
    return false;
  }
}

// Função para testar upload de imagem
async function testImageUpload() {
  try {
    // Criar um arquivo de imagem de teste se não existir
    const testImagePath = path.join(__dirname, 'test-image.png');
    if (!fs.existsSync(testImagePath)) {
      console.log('Criando imagem de teste...');
      // Criar uma imagem simples (1x1 pixel)
      const buffer = Buffer.from([
        0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D,
        0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
        0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4, 0x89, 0x00, 0x00, 0x00,
        0x0A, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C, 0x63, 0x00, 0x01, 0x00, 0x00,
        0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, 0xB4, 0x00, 0x00, 0x00, 0x00, 0x49,
        0x45, 0x4E, 0x44, 0xAE, 0x42, 0x60, 0x82
      ]);
      fs.writeFileSync(testImagePath, buffer);
    }

    // Criar FormData e adicionar a imagem
    const formData = new FormData();
    formData.append('image', fs.createReadStream(testImagePath));

    // Enviar requisição
    const response = await axios.post(`${API_URL}/media/upload/image`, formData, {
      headers: {
        ...formData.getHeaders(),
        'Authorization': `Bearer ${authToken}`
      }
    });

    console.log('Upload de imagem bem-sucedido!');
    console.log('URL da imagem:', response.data.mediaUrl);
    return response.data.mediaUrl;
  } catch (error) {
    console.error('Erro ao fazer upload de imagem:', error.response?.data || error.message);
    return null;
  }
}

// Função para testar upload de áudio
async function testAudioUpload() {
  try {
    // Criar um arquivo de áudio de teste se não existir
    const testAudioPath = path.join(__dirname, 'test-audio.mp3');
    if (!fs.existsSync(testAudioPath)) {
      console.log('Criando áudio de teste...');
      // Criar um arquivo MP3 vazio (cabeçalho mínimo)
      const buffer = Buffer.from([
        0xFF, 0xFB, 0x90, 0x44, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
      ]);
      fs.writeFileSync(testAudioPath, buffer);
    }

    // Criar FormData e adicionar o áudio
    const formData = new FormData();
    formData.append('audio', fs.createReadStream(testAudioPath));
    formData.append('duration', '3.5'); // Duração em segundos

    // Enviar requisição
    const response = await axios.post(`${API_URL}/media/upload/audio`, formData, {
      headers: {
        ...formData.getHeaders(),
        'Authorization': `Bearer ${authToken}`
      }
    });

    console.log('Upload de áudio bem-sucedido!');
    console.log('URL do áudio:', response.data.mediaUrl);
    console.log('Duração:', response.data.audioDuration);
    return response.data.mediaUrl;
  } catch (error) {
    console.error('Erro ao fazer upload de áudio:', error.response?.data || error.message);
    return null;
  }
}

// Função para testar envio de mensagem com mídia
async function testSendMessageWithMedia(conversationId, mediaUrl, type) {
  try {
    const response = await axios.post(`${API_URL}/conversations/${conversationId}/messages`, {
      type,
      mediaUrl,
      text: type === 'image' ? 'Teste de imagem' : 'Teste de áudio',
      audioDuration: type === 'audio' ? 3.5 : undefined
    }, {
      headers: {
        'Authorization': `Bearer ${authToken}`
      }
    });

    console.log(`Mensagem com ${type} enviada com sucesso!`);
    console.log('ID da mensagem:', response.data.data.id);
    return true;
  } catch (error) {
    console.error(`Erro ao enviar mensagem com ${type}:`, error.response?.data || error.message);
    return false;
  }
}

// Função para criar uma conversa de teste
async function createTestConversation() {
  try {
    // Primeiro, verificar se já existe uma conversa
    const conversationsResponse = await axios.get(`${API_URL}/conversations`, {
      headers: {
        'Authorization': `Bearer ${authToken}`
      }
    });
    
    if (conversationsResponse.data.conversations && conversationsResponse.data.conversations.length > 0) {
      console.log('Usando conversa existente');
      return conversationsResponse.data.conversations[0].id;
    }
    
    // Se não existir, criar uma conversa de teste (consigo mesmo)
    const userResponse = await axios.get(`${API_URL}/users/me`, {
      headers: {
        'Authorization': `Bearer ${authToken}`
      }
    });
    
    const userId = userResponse.data.user.id;
    
    const response = await axios.post(`${API_URL}/conversations`, {
      participantIds: [userId],
      type: 'private'
    }, {
      headers: {
        'Authorization': `Bearer ${authToken}`
      }
    });
    
    console.log('Conversa criada com sucesso!');
    return response.data.conversation.id;
  } catch (error) {
    console.error('Erro ao criar conversa:', error.response?.data || error.message);
    return null;
  }
}

// Função principal para executar os testes
async function runTests() {
  console.log('Iniciando testes de upload de mídia...');
  
  // Login
  const loggedIn = await login();
  if (!loggedIn) {
    console.error('Não foi possível autenticar. Abortando testes.');
    return;
  }
  
  // Criar conversa de teste
  const conversationId = await createTestConversation();
  if (!conversationId) {
    console.error('Não foi possível criar uma conversa de teste. Abortando testes.');
    return;
  }
  
  // Testar upload de imagem
  const imageUrl = await testImageUpload();
  if (imageUrl) {
    // Testar envio de mensagem com imagem
    await testSendMessageWithMedia(conversationId, imageUrl, 'image');
  }
  
  // Testar upload de áudio
  const audioUrl = await testAudioUpload();
  if (audioUrl) {
    // Testar envio de mensagem com áudio
    await testSendMessageWithMedia(conversationId, audioUrl, 'audio');
  }
  
  console.log('Testes concluídos!');
}

// Executar os testes
runTests().catch(console.error);
