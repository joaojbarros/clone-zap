import express, { Express, Request, Response } from 'express';
import http from 'http';
import dotenv from 'dotenv';
import cors from 'cors';
import routes from './routes';
import { setupSocketIO } from './services/socket.service';

// Configurar variáveis de ambiente
dotenv.config();

const app: Express = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 8000;

// Middlewares
app.use(cors()); // Habilitar CORS para todas as rotas
app.use(express.json()); // Para parsear JSON no corpo das requisições

// Configurar rotas da API
app.use('/api', routes);

// Rota de teste
app.get('/', (req: Request, res: Response) => {
  res.send('Servidor do WhatsApp Clone está rodando!');
});

// Configuração do Socket.IO
const io = setupSocketIO(server);

server.listen(PORT, () => {
  console.log(`Servidor backend rodando na porta ${PORT}`);
});

export { io }; // Exportar io para ser usado em outros módulos, se necessário

