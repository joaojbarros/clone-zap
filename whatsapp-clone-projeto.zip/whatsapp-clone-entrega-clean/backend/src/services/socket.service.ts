import { Server as SocketIOServer } from 'socket.io';
import { Server as HttpServer } from 'http';
import jwt from 'jsonwebtoken';
import { db } from '../config/firebase';
import { firestore } from 'firebase-admin';
import dotenv from 'dotenv';

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'seuSuperSegredo';

interface DecodedToken {
  userId: string;
  email: string;
  iat: number;
  exp: number;
}

// Mapeamento de usuários conectados: userId -> socketId
const connectedUsers = new Map<string, string>();

export const setupSocketIO = (server: HttpServer) => {
  const io = new SocketIOServer(server, {
    cors: {
      origin: process.env.FRONTEND_URL || "http://localhost:3000",
      methods: ["GET", "POST"]
    }
  });

  // Middleware de autenticação para Socket.IO
  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    
    if (!token) {
      return next(new Error('Token de autenticação não fornecido.'));
    }

    try {
      const decoded = jwt.verify(token, JWT_SECRET) as DecodedToken;
      socket.data.user = {
        userId: decoded.userId,
        email: decoded.email
      };
      next();
    } catch (error) {
      return next(new Error('Token inválido ou expirado.'));
    }
  });

  io.on('connection', async (socket) => {
    const userId = socket.data.user.userId;
    console.log(`Usuário conectado: ${userId}, Socket ID: ${socket.id}`);
    
    // Armazenar o socketId do usuário
    connectedUsers.set(userId, socket.id);
    
    // Atualizar status do usuário para online
    try {
      await db.collection('users').doc(userId).update({
        status: 'online',
        lastSeen: new Date()
      });
      
      // Notificar contatos que o usuário está online
      const userDoc = await db.collection('users').doc(userId).get();
      const userData = userDoc.data();
      
      if (userData && userData.contacts && userData.contacts.length > 0) {
        userData.contacts.forEach((contactId: string) => {
          const contactSocketId = connectedUsers.get(contactId);
          if (contactSocketId) {
            io.to(contactSocketId).emit('userOnline', { userId });
          }
        });
      }
    } catch (error) {
      console.error('Erro ao atualizar status do usuário:', error);
    }

    // Entrar em salas para todas as conversas do usuário
    try {
      const conversationsRef = db.collection('conversations')
        .where('participants', 'array-contains', userId);
      
      const snapshot = await conversationsRef.get();
      
      snapshot.forEach(doc => {
        socket.join(doc.id);
        console.log(`Usuário ${userId} entrou na sala: ${doc.id}`);
      });
    } catch (error) {
      console.error('Erro ao entrar nas salas de conversa:', error);
    }

    // Evento: usuário entra em uma conversa específica (para notificações de digitação, etc.)
    socket.on('joinConversation', (conversationId) => {
      socket.join(conversationId);
      console.log(`Usuário ${userId} entrou ativamente na conversa: ${conversationId}`);
    });

    // Evento: usuário sai de uma conversa específica
    socket.on('leaveConversation', (conversationId) => {
      socket.leave(conversationId);
      console.log(`Usuário ${userId} saiu ativamente da conversa: ${conversationId}`);
    });

    // Evento: usuário está digitando
    socket.on('typing', ({ conversationId }) => {
      socket.to(conversationId).emit('userTyping', { userId, conversationId });
    });

    // Evento: usuário parou de digitar
    socket.on('stopTyping', ({ conversationId }) => {
      socket.to(conversationId).emit('userStopTyping', { userId, conversationId });
    });

    // Evento: enviar mensagem
    socket.on('sendMessage', async (messageData) => {
      try {
        const { conversationId, text, type, mediaUrl, audioDuration } = messageData;
        
        // Verificar se a conversa existe e se o usuário é participante
        const conversationRef = db.collection('conversations').doc(conversationId);
        const conversationDoc = await conversationRef.get();
        
        if (!conversationDoc.exists) {
          socket.emit('error', { message: 'Conversa não encontrada.' });
          return;
        }

        const conversation = conversationDoc.data();
        if (!conversation?.participants.includes(userId)) {
          socket.emit('error', { message: 'Acesso negado a esta conversa.' });
          return;
        }

        // Criar nova mensagem
        const timestamp = new Date();
        const newMessage = {
          conversationId,
          senderId: userId,
          type: type || 'text',
          text,
          mediaUrl,
          audioDuration,
          timestamp,
          status: {
            deliveredTo: [userId], // Inicialmente entregue apenas ao remetente
            readBy: [userId]       // Inicialmente lida apenas pelo remetente
          }
        };

        // Salvar a mensagem
        const messageRef = await db.collection('conversations')
          .doc(conversationId)
          .collection('messages')
          .add(newMessage);

        // Atualizar lastMessage na conversa
        await conversationRef.update({
          lastMessage: {
            messageId: messageRef.id,
            text: text || `[${type.toUpperCase()}]`,
            senderId: userId,
            timestamp
          },
          updatedAt: timestamp
        });

        // Adicionar ID à mensagem
        const createdMessage = {
          id: messageRef.id,
          ...newMessage
        };

        // Emitir evento para todos os participantes da conversa
        io.to(conversationId).emit('newMessage', createdMessage);

        // Marcar como entregue para usuários online
        conversation.participants.forEach(async (participantId: string) => {
          if (participantId !== userId && connectedUsers.has(participantId)) {
            // Atualizar status de entrega
            await messageRef.update({
              'status.deliveredTo': firestore.FieldValue.arrayUnion(participantId)
            });
            
            // Notificar remetente sobre entrega
            socket.emit('messageDelivered', { 
              messageId: messageRef.id, 
              userId: participantId,
              conversationId
            });
          }
        });

      } catch (error) {
        console.error('Erro ao processar mensagem via WebSocket:', error);
        socket.emit('error', { message: 'Erro ao enviar mensagem.' });
      }
    });

    // Evento: marcar mensagem como lida
    socket.on('markMessageAsRead', async ({ messageId, conversationId }) => {
      try {
        const messageRef = db.collection('conversations')
          .doc(conversationId)
          .collection('messages')
          .doc(messageId);
        
        const messageDoc = await messageRef.get();
        
        if (!messageDoc.exists) {
          socket.emit('error', { message: 'Mensagem não encontrada.' });
          return;
        }

        // Atualizar status de leitura
        await messageRef.update({
          'status.readBy': firestore.FieldValue.arrayUnion(userId)
        });

        // Notificar remetente que a mensagem foi lida
        const message = messageDoc.data();
        if (message && message.senderId !== userId) {
          const senderSocketId = connectedUsers.get(message.senderId);
          if (senderSocketId) {
            io.to(senderSocketId).emit('messageRead', { 
              messageId, 
              userId,
              conversationId
            });
          }
        }
      } catch (error) {
        console.error('Erro ao marcar mensagem como lida:', error);
        socket.emit('error', { message: 'Erro ao marcar mensagem como lida.' });
      }
    });

    // Evento: desconexão
    socket.on('disconnect', async () => {
      console.log(`Usuário desconectado: ${userId}`);
      
      // Remover do mapa de usuários conectados
      connectedUsers.delete(userId);
      
      // Atualizar status do usuário para offline
      const lastSeen = new Date();
      try {
        await db.collection('users').doc(userId).update({
          status: 'offline',
          lastSeen
        });
        
        // Notificar contatos que o usuário está offline
        const userDoc = await db.collection('users').doc(userId).get();
        const userData = userDoc.data();
        
        if (userData && userData.contacts && userData.contacts.length > 0) {
          userData.contacts.forEach((contactId: string) => {
            const contactSocketId = connectedUsers.get(contactId);
            if (contactSocketId) {
              io.to(contactSocketId).emit('userOffline', { 
                userId, 
                lastSeen 
              });
            }
          });
        }
      } catch (error) {
        console.error('Erro ao atualizar status do usuário para offline:', error);
      }
    });
  });

  return io;
};
