import admin from 'firebase-admin';
import dotenv from 'dotenv';

dotenv.config();

// Variáveis de ambiente para configuração do Firebase
// Estas variáveis devem ser definidas no arquivo .env
// Exemplo:
// FIREBASE_PROJECT_ID="seu-project-id"
// FIREBASE_CLIENT_EMAIL="firebase-adminsdk-xxxx@seu-project-id.iam.gserviceaccount.com"
// FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQD...\n-----END PRIVATE KEY-----"
// FIREBASE_STORAGE_BUCKET="seu-project-id.appspot.com"

const serviceAccount = {
  projectId: process.env.FIREBASE_PROJECT_ID,
  clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
  privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'), // Substituir \n por quebras de linha reais
};

if (!admin.apps.length) {
  try {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount as admin.ServiceAccount),
      storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
    });
    console.log('Firebase Admin SDK inicializado com sucesso.');
  } catch (error) {
    console.error('Erro ao inicializar Firebase Admin SDK:', error);
    // Considerar lançar um erro aqui ou tratar de forma mais robusta
    // dependendo da criticidade da conexão com o Firebase para a aplicação.
  }
}

const db = admin.firestore();
const storage = admin.storage().bucket();

export { db, storage, admin as firebaseAdmin };

