export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  avatarUrl: string;
  status: 'online' | 'offline';
  lastSeen: Date;
  contacts: string[]; // Array de IDs de usuários
  createdAt: Date;
  updatedAt: Date;
}

export interface Conversation {
  id: string;
  participants: string[]; // Array de IDs de usuários
  type: 'private' | 'group';
  lastMessage?: {
    messageId: string;
    text: string;
    senderId: string;
    timestamp: Date;
  };
  createdAt: Date;
  updatedAt: Date;
  groupName?: string; // Apenas para conversas de grupo
  groupAvatarUrl?: string; // Apenas para conversas de grupo
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  type: 'text' | 'image' | 'audio' | 'emoji';
  text?: string;
  mediaUrl?: string;
  audioDuration?: number;
  timestamp: Date;
  status: {
    deliveredTo: string[]; // Array de IDs de usuários
    readBy: string[]; // Array de IDs de usuários
  };
}
